const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Ensure /public exists
const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Write SVG icon
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0284c7" />
      <stop offset="50%" stop-color="#0d9488" />
      <stop offset="100%" stop-color="#059669" />
    </linearGradient>
    <linearGradient id="glow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.8" />
      <stop offset="100%" stop-color="#34d399" stop-opacity="0.8" />
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#042f2e" flood-opacity="0.4" />
    </filter>
  </defs>

  <!-- Background with rounded squircle for app icon -->
  <rect width="512" height="512" rx="112" fill="url(#bg)" />

  <!-- Inner glowing aura -->
  <circle cx="256" cy="240" r="170" fill="none" stroke="url(#glow)" stroke-width="4" opacity="0.4" />

  <!-- Steam Clouds / Bubbles group with shadow -->
  <g filter="url(#shadow)">
    <!-- Main steam blast / nozzle -->
    <path d="M 210 340 C 180 340 160 320 160 290 C 160 270 175 255 190 250 C 185 235 195 210 220 205 C 235 170 275 165 295 190 C 315 180 345 195 345 225 C 365 235 370 265 355 285 C 370 305 355 340 325 340 Z" fill="#ffffff" />
    
    <!-- Steam nozzle handle / vapor device emblem -->
    <circle cx="210" cy="180" r="14" fill="#a7f3d0" />
    <circle cx="340" cy="170" r="18" fill="#bae6fd" />
    <circle cx="370" cy="210" r="12" fill="#ffffff" opacity="0.9" />

    <!-- AlloVap "V" Spark in center of steam -->
    <path d="M 230 240 L 256 295 L 282 240" fill="none" stroke="#059669" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" />
    <!-- Sparkle star top-right -->
    <path d="M 285 220 Q 295 220 295 210 Q 295 220 305 220 Q 295 220 295 230 Q 295 220 285 220 Z" fill="#facc15" />
  </g>

  <!-- Text "AlloVap" bottom badge -->
  <rect x="116" y="380" width="280" height="60" rx="30" fill="#0f172a" opacity="0.85" />
  <text x="256" y="422" font-family="system-ui, -apple-system, sans-serif" font-size="34" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="1">AlloVap</text>
  <circle cx="362" cy="406" r="6" fill="#10b981" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent);
console.log('Saved icon.svg');

// Simple PNG encoder from RGBA buffer
function createPng(width, height, getPixel) {
  // PNG signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // deflate compression
  ihdrData[11] = 0; // filter method
  ihdrData[12] = 0; // no interlace

  const ihdrChunk = createChunk('IHDR', ihdrData);

  // Raw image data with filter type 0 (None) before each scanline
  const scanlineLength = 1 + width * 4;
  const rawData = Buffer.alloc(height * scanlineLength);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y, width, height);
      const pixelOffset = rowOffset + 1 + x * 4;
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', compressedData);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// CRC32 table
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function createChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const length = data.length;
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(length, 0);

  const crcData = Buffer.concat([typeBuf, data]);
  const crcVal = crc32(crcData);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crcVal, 0);

  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

// Pixel generator for AlloVap brand icon
function generateIconPixels(isMaskable) {
  return function (x, y, w, h) {
    // Normalised coords -1 to 1
    const nx = (x / w) * 2 - 1;
    const ny = (y / h) * 2 - 1;
    const distFromCenter = Math.sqrt(nx * nx + ny * ny);

    // If maskable, fill the entire area with background gradient; if standard, round squircle
    if (!isMaskable) {
      // Rounded corner check (radius ~ 0.3)
      const absX = Math.abs(nx);
      const absY = Math.abs(ny);
      if (absX > 0.65 && absY > 0.65) {
        const cornerDist = Math.sqrt(Math.pow(absX - 0.65, 2) + Math.pow(absY - 0.65, 2));
        if (cornerDist > 0.32) {
          return [0, 0, 0, 0]; // Transparent outside rounded corner
        }
      }
    }

    // Base background gradient: Top-Left (Sky Blue: 2, 132, 199) -> Bottom-Right (Emerald: 5, 150, 105)
    const t = (nx + ny + 2) / 4; // 0 to 1
    let r = Math.round(2 * (1 - t) + 5 * t);
    let g = Math.round(132 * (1 - t) + 150 * t);
    let b = Math.round(199 * (1 - t) + 105 * t);

    // Inner symbol scale
    const scale = isMaskable ? 0.7 : 0.85;
    const sx = nx / scale;
    const sy = ny / scale;

    // Steam cloud / bubbles
    const d1 = Math.sqrt(Math.pow(sx + 0.15, 2) + Math.pow(sy + 0.05, 2));
    const d2 = Math.sqrt(Math.pow(sx - 0.15, 2) + Math.pow(sy + 0.05, 2));
    const d3 = Math.sqrt(Math.pow(sx, 2) + Math.pow(sy - 0.1, 2));
    const d4 = Math.sqrt(Math.pow(sx - 0.3, 2) + Math.pow(sy - 0.25, 2));
    const d5 = Math.sqrt(Math.pow(sx + 0.25, 2) + Math.pow(sy - 0.28, 2));

    const inPuff = d1 < 0.35 || d2 < 0.38 || d3 < 0.36;
    const inSmallBubble = d4 < 0.09 || d5 < 0.07;

    if (inPuff) {
      // V symbol inside puff: distance from two lines forming a 'V'
      // Left line of V: from (-0.1, -0.1) to (0, 0.15)
      // Right line of V: from (0.1, -0.1) to (0, 0.15)
      const vDistL = Math.abs((0.25) * (sx) - (-0.1) * (sy - 0.15)) / Math.sqrt(0.25 * 0.25 + 0.01);
      const vDistR = Math.abs((-0.25) * (sx) - (0.1) * (sy - 0.15)) / Math.sqrt(0.25 * 0.25 + 0.01);
      const inV = (sy >= -0.12 && sy <= 0.18) && ((vDistL < 0.035 && sx <= 0.05) || (vDistR < 0.035 && sx >= -0.05));

      if (inV) {
        return [5, 150, 105, 255]; // Deep Emerald 'V'
      }
      return [255, 255, 255, 255]; // Pure White steam cloud
    }

    if (inSmallBubble) {
      return [186, 230, 253, 235]; // Light cyan bubble
    }

    // Bottom brand bar
    if (sy > 0.45 && sy < 0.72 && Math.abs(sx) < 0.65) {
      return [15, 23, 42, 230]; // Dark slate badge
    }

    return [r, g, b, 255];
  };
}

// Generate files
const sizes = [
  { file: 'pwa-192x192.png', size: 192, maskable: false },
  { file: 'pwa-512x512.png', size: 512, maskable: false },
  { file: 'pwa-maskable-512x512.png', size: 512, maskable: true },
  { file: 'apple-touch-icon.png', size: 180, maskable: false },
  { file: 'favicon.png', size: 64, maskable: false },
];

for (const { file, size, maskable } of sizes) {
  const pngBuffer = createPng(size, size, generateIconPixels(maskable));
  fs.writeFileSync(path.join(publicDir, file), pngBuffer);
  console.log(`Generated ${file} (${size}x${size})`);
}

console.log('All icons generated successfully!');
