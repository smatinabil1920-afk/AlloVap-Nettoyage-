# AlloVap Challenge — بداية تحويل Android

## شنوّة تبدّل؟
- أضفنا إعداد Capacitor لاسم التطبيق `AlloVap Challenge`.
- Package ID: `com.allovap.challenge`.
- مجلد ملفات الويب المبنية هو `dist`.
- أضفنا أمر بناء APK تجريبي عبر GitHub Actions.
- لم نحذف ملفات React أو الألعاب أو الصور أو الأسئلة.

## تنبيه مهم
هذا المشروع ما زال واجهته React تعمل داخل حاوية Android عبر Capacitor (WebView). هذا يحافظ على الكود الحالي، لكنه ليس إعادة كتابة Native بـ Kotlin.

## بناء APK من GitHub (يمكن بدءه من الهاتف)
1. أنشئ مستودع GitHub جديداً، ويفضّل Private لحماية ملفات المشروع.
2. ارفع محتويات هذا المجلد إلى المستودع، مع الحفاظ على مجلد `.github/workflows`.
3. افتح تبويب Actions في المستودع.
4. اختر `Build AlloVap Android APK` ثم `Run workflow`.
5. بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم `AlloVap-Challenge-debug-APK`.
6. فكّ ZIP الناتج وخذ `app-debug.apk` وثبّته على هاتف Android.

## أوامر البناء محلياً
يتطلب ذلك Node.js وAndroid Studio وAndroid SDK:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

## قبل النشر على Google Play
- يلزم إعداد Firebase وخدمات خلفية آمنة للجوائز والكوبونات؛ لا تستخدم التخزين المحلي الحالي كمصدر موثوق للجوائز الحقيقية.
- يلزم إنشاء مفتاح توقيع خاص وحفظه بأمان.
- أنشئ Signed AAB من Android Studio أو Gradle بعد إعداد التوقيع.
- لا ترفع ملفات keystore أو كلمات المرور إلى GitHub.

## ملاحظة
Workflow الحالي ينشئ Debug APK للتجربة فقط، وليس ملف Release موقّعاً للنشر على Google Play.
