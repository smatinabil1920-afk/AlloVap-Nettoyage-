import { Coupon, BookingSubmission, WheelPrize } from '../types';

const COUPONS_STORAGE_KEY = 'allovap_challenge_coupons_v2';
const BOOKINGS_STORAGE_KEY = 'allovap_challenge_bookings_v2';

// 7 days in milliseconds
export const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export function calculateDiscount(score: number, total: number): number {
  if (total <= 0) return 1;
  const ratio = score / total;
  // Calculate discount from 1% to 10%
  const calculated = Math.round(ratio * 10);
  return Math.min(10, Math.max(1, calculated));
}

export function generateCouponCode(discountPercent: number): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let rand = '';
  for (let i = 0; i < 4; i++) {
    rand += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `AV-7D-${discountPercent}P-${rand}`;
}

export function createCoupon(score: number, totalQuestions: number): Coupon {
  const discount = calculateDiscount(score, totalQuestions);
  const now = new Date();
  const expiry = new Date(now.getTime() + SEVEN_DAYS_MS);

  const coupon: Coupon = {
    id: `c_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    code: generateCouponCode(discount),
    discountPercentage: discount,
    score,
    totalQuestions,
    issueDate: now.toISOString(),
    expiryDate: expiry.toISOString(),
    status: 'active',
    prizeType: 'quiz'
  };

  saveCoupon(coupon);
  return coupon;
}

export const DEFAULT_WHEEL_PRIZES: WheelPrize[] = [
  {
    id: 'p_5',
    label: 'تخفيض 5%',
    description: 'خصم 5% على أي خدمة تنظيف وتطهير بالبخار لدى AlloVap',
    discountPercentage: 5,
    color: '#1E40AF', // Deep Azure
    textColor: '#FFFFFF',
    probability: 35
  },
  {
    id: 'p_10',
    label: 'تخفيض 10%',
    description: 'خصم 10% على غسيل الصالونات أو السيارات أو المراتب',
    discountPercentage: 10,
    color: '#059669', // Emerald Green
    textColor: '#FFFFFF',
    probability: 15
  },
  {
    id: 'p_15',
    label: 'تخفيض 15%',
    description: 'خصم استثنائي 15% على باقات التنظيف المتكاملة',
    discountPercentage: 15,
    color: '#D97706', // Gold Amber
    textColor: '#FFFFFF',
    probability: 2
  },
  {
    id: 'p_curtain',
    label: 'غسيل ستائر مجاني',
    description: 'تنظيف وتطهير مجاني لستائر الصالون في مكانها مع أي حجز لصالون',
    discountPercentage: 100,
    isFreeService: true,
    color: '#0891B2', // Cyan Teal
    textColor: '#FFFFFF',
    probability: 3
  },
  {
    id: 'p_none',
    label: 'حاول مرة أخرى',
    description: 'حظ أوفر! العب لعبة التنظيف أو أجب عن الأسئلة لربح تخفيض مؤكد',
    discountPercentage: 0,
    color: '#64748B', // Neutral Slate
    textColor: '#FFFFFF',
    probability: 45
  }
];

const WHEEL_CONFIG_KEY = 'allovap_wheel_prizes_v2';

export function getWheelPrizesConfig(): WheelPrize[] {
  try {
    const raw = localStorage.getItem(WHEEL_CONFIG_KEY);
    if (!raw) return DEFAULT_WHEEL_PRIZES;
    return JSON.parse(raw);
  } catch {
    return DEFAULT_WHEEL_PRIZES;
  }
}

export function saveWheelPrizesConfig(prizes: WheelPrize[]): void {
  localStorage.setItem(WHEEL_CONFIG_KEY, JSON.stringify(prizes));
}

export function pickFairWheelPrize(prizes: WheelPrize[]): { prize: WheelPrize; index: number } {
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (let i = 0; i < prizes.length; i++) {
    cumulative += prizes[i].probability;
    if (rand <= cumulative) {
      return { prize: prizes[i], index: i };
    }
  }
  return { prize: prizes[prizes.length - 1], index: prizes.length - 1 };
}

export function createWheelCoupon(prize: WheelPrize): Coupon {
  const now = new Date();
  const expiry = new Date(now.getTime() + SEVEN_DAYS_MS);

  const coupon: Coupon = {
    id: `c_wheel_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    code: prize.isFreeService
      ? `AV-7D-FREE-RIDEAU-${Math.random().toString(36).substring(2, 6).toUpperCase()}`
      : generateCouponCode(prize.discountPercentage),
    discountPercentage: prize.discountPercentage,
    score: 1,
    totalQuestions: 1,
    issueDate: now.toISOString(),
    expiryDate: expiry.toISOString(),
    status: 'active',
    prizeType: 'wheel',
    freeServiceName: prize.isFreeService ? 'غسيل ستائر مجاني' : undefined
  };

  saveCoupon(coupon);
  return coupon;
}

export function createGameCoupon(discountPercent: number, finalScore: number): Coupon {
  const now = new Date();
  const expiry = new Date(now.getTime() + SEVEN_DAYS_MS);

  const coupon: Coupon = {
    id: `c_game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    code: `AV-7D-GAME-${discountPercent}P-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
    discountPercentage: discountPercent,
    score: finalScore,
    totalQuestions: 5,
    issueDate: now.toISOString(),
    expiryDate: expiry.toISOString(),
    status: 'active',
    prizeType: 'game'
  };

  saveCoupon(coupon);
  return coupon;
}

export function getStoredCoupons(): Coupon[] {
  try {
    const raw = localStorage.getItem(COUPONS_STORAGE_KEY);
    if (!raw) {
      // Seed initial coupons for testing admin validation and real scenarios
      const now = Date.now();
      const initial: Coupon[] = [
        {
          id: 'c_demo_active_1',
          code: 'AV-7D-10P-BEST',
          discountPercentage: 10,
          score: 10,
          totalQuestions: 10,
          issueDate: new Date(now - 2 * 24 * 60 * 60 * 1000).toISOString(),
          expiryDate: new Date(now + 5 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active'
        },
        {
          id: 'c_demo_used_1',
          code: 'AV-7D-8P-USED',
          discountPercentage: 8,
          score: 8,
          totalQuestions: 10,
          issueDate: new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString(),
          expiryDate: new Date(now + 3 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'used',
          usedAt: new Date(now - 1 * 24 * 60 * 60 * 1000).toISOString(),
          usedBookingId: 'BK-1082',
          validatedBy: 'Admin AlloVap (مركزي)'
        },
        {
          id: 'c_demo_expired_1',
          code: 'AV-7D-9P-PAST',
          discountPercentage: 9,
          score: 9,
          totalQuestions: 10,
          issueDate: new Date(now - 10 * 24 * 60 * 60 * 1000).toISOString(),
          expiryDate: new Date(now - 3 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'expired'
        }
      ];
      localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }

    const coupons: Coupon[] = JSON.parse(raw);
    const now = Date.now();

    // Auto-update expired coupons
    let changed = false;
    const updated = coupons.map(c => {
      const expTime = new Date(c.expiryDate).getTime();
      if (c.status === 'active' && now > expTime) {
        changed = true;
        return { ...c, status: 'expired' as const };
      }
      return c;
    });

    if (changed) {
      localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(updated));
    }

    return updated;
  } catch {
    return [];
  }
}

export function saveCoupon(coupon: Coupon): void {
  const coupons = getStoredCoupons();
  const existingIdx = coupons.findIndex(c => c.id === coupon.id || c.code === coupon.code);
  if (existingIdx >= 0) {
    coupons[existingIdx] = coupon;
  } else {
    coupons.unshift(coupon);
  }
  localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(coupons));
}

export function findCouponByCode(code: string): Coupon | null {
  const normalized = code.trim().toUpperCase();
  const coupons = getStoredCoupons();
  const found = coupons.find(c => c.code === normalized);
  if (!found) return null;

  // Check 7 days expiry
  const now = Date.now();
  const expTime = new Date(found.expiryDate).getTime();
  if (found.status === 'active' && now > expTime) {
    found.status = 'expired';
    saveCoupon(found);
  }
  return found;
}

export function markCouponAsUsed(code: string, bookingId: string, adminName: string = 'النظام الآلي / الإدارة'): { success: boolean; message: string; coupon?: Coupon } {
  const coupon = findCouponByCode(code);
  if (!coupon) {
    return { success: false, message: 'الكوبون غير موجود في قاعدة بيانات AlloVap' };
  }

  if (coupon.status === 'used') {
    return { success: false, message: 'هذا الكوبون تم استعماله مسبقاً وغير قابل للاستعمال مرة ثانية (مسموح مرة واحدة فقط)' };
  }

  const now = Date.now();
  const expTime = new Date(coupon.expiryDate).getTime();
  if (now > expTime || coupon.status === 'expired') {
    coupon.status = 'expired';
    saveCoupon(coupon);
    return { success: false, message: 'انتهت صلاحية هذا الكوبون (صالح لمدة 7 أيام فقط من تاريخ صدوره)' };
  }

  coupon.status = 'used';
  coupon.usedAt = new Date().toISOString();
  coupon.usedBookingId = bookingId;
  coupon.validatedBy = adminName;
  saveCoupon(coupon);

  return { success: true, message: `تم قبول وتأكيد الكوبون بنجاح! تم تطبيق تخفيض ${coupon.discountPercentage}%`, coupon };
}

export function adminValidateCoupon(code: string, adminNotes: string = 'مصادق عليه من قبل المشرف'): { success: boolean; message: string; coupon?: Coupon } {
  return markCouponAsUsed(code, `ADM-VAL-${Date.now().toString().slice(-4)}`, adminNotes);
}

// Bookings Storage & Management
export function getStoredBookings(): BookingSubmission[] {
  try {
    const raw = localStorage.getItem(BOOKINGS_STORAGE_KEY);
    if (!raw) {
      // Seed a sample booking
      const initial: BookingSubmission[] = [
        {
          id: 'BK-1082',
          customerName: 'أنيس البجاوي',
          phone: '+216 98 450 120',
          city: 'تونس (المنزه 9)',
          address: 'إقامة الياسمين، عمارة ب',
          serviceType: 'تنظيف صالون 7 مقاعد بالبخار والاستخراج',
          preferredDate: '2026-11-05',
          couponCode: 'AV-7D-8P-USED',
          originalPrice: 150,
          discountAmount: 12,
          finalPrice: 138,
          notes: 'صالون مخمل رمادي مع بقع عصير سابقة',
          createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          status: 'confirmed'
        }
      ];
      localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveBooking(booking: BookingSubmission): void {
  const list = getStoredBookings();
  list.unshift(booking);
  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(list));

  // If booking had a valid coupon, mark it as used
  if (booking.couponCode) {
    markCouponAsUsed(booking.couponCode, booking.id, 'حجز مباشر من الموقع');
  }
}

export function formatTimeRemaining(expiryDateISO: string): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  formattedText: string;
} {
  const diff = new Date(expiryDateISO).getTime() - Date.now();
  if (diff <= 0) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      isExpired: true,
      formattedText: 'انتهت صلاحية الكوبون (مرت 7 أيام)'
    };
  }

  const days = Math.floor(diff / (24 * 60 * 60 * 1000));
  const hours = Math.floor((diff % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  const minutes = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
  const seconds = Math.floor((diff % (60 * 1000)) / 1000);

  return {
    days,
    hours,
    minutes,
    seconds,
    isExpired: false,
    formattedText: `${days} يوم و ${hours} ساعة و ${minutes} دقيقة`
  };
}

export function formatDateArabic(isoDate: string): string {
  try {
    const d = new Date(isoDate);
    return d.toLocaleDateString('ar-TN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoDate;
  }
}
