import React, { useState, useEffect } from 'react';
import { ThreeChoicesHome } from './components/ThreeChoicesHome';
import { SectionNav } from './components/SectionNav';
import { WheelOfFortune } from './components/WheelOfFortune';
import { CleaningGame } from './components/CleaningGame';
import { QuizView } from './components/QuizView';
import { QuestionBankView } from './components/QuestionBankView';
import { BookingSection } from './components/BookingSection';
import { AdminPortal } from './components/AdminPortal';
import { CouponCard } from './components/CouponCard';
import { getStoredCoupons } from './utils/couponManager';
import { Coupon } from './types';
import { X, Tag, BookOpen, Sparkles, Trophy } from 'lucide-react';

export default function App() {
  // Main view: 'home' is the first screen with EXACTLY three main choices!
  const [currentView, setCurrentView] = useState<'home' | 'wheel' | 'game' | 'quiz'>('home');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('allovap_theme') === 'dark';
  });

  // Modals & subviews accessible from within the three sections
  const [showCouponsModal, setShowCouponsModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [quizSubTab, setQuizSubTab] = useState<'challenge' | 'bank'>('challenge');

  const [bookingCouponCode, setBookingCouponCode] = useState<string>('');
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);
  const [couponsList, setCouponsList] = useState<Coupon[]>([]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('allovap_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('allovap_theme', 'light');
    }
  }, [darkMode]);

  // Load coupons from storage
  const refreshCoupons = () => {
    const list = getStoredCoupons();
    setCouponsList(list);
    const activeOne = list.find(c => c.status === 'active');
    setActiveCoupon(activeOne || null);
  };

  useEffect(() => {
    refreshCoupons();
  }, [currentView, showCouponsModal, showBookingModal]);

  const handleBookWithCoupon = (code: string) => {
    setBookingCouponCode(code);
    setShowCouponsModal(false);
    setShowBookingModal(true);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors selection:bg-emerald-500 selection:text-white">
      {/* 1. HOMEPAGE: EXACTLY THREE MAIN CHOICES */}
      {currentView === 'home' && (
        <ThreeChoicesHome
          onSelectChoice={(choice) => {
            setCurrentView(choice);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
        />
      )}

      {/* 2. DEDICATED SECTIONS (Wheel / Game / Quiz) */}
      {currentView !== 'home' && (
        <div className="flex flex-col min-h-screen">
          {/* Section Navigation Header */}
          <SectionNav
            currentSection={currentView}
            onReturnHome={() => {
              setCurrentView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBooking={() => setShowBookingModal(true)}
            onOpenCoupons={() => {
              refreshCoupons();
              setShowCouponsModal(true);
            }}
            onOpenAdmin={() => setShowAdminModal(true)}
          />

          {/* Section Main Content */}
          <main className="flex-1 py-4 sm:py-8">
            {/* Wheel of Fortune Section */}
            {currentView === 'wheel' && (
              <WheelOfFortune
                onBookWithCoupon={handleBookWithCoupon}
                onGoToGame={() => setCurrentView('game')}
                onGoToQuiz={() => setCurrentView('quiz')}
              />
            )}

            {/* Cleaning Game Section */}
            {currentView === 'game' && (
              <CleaningGame
                onBookWithCoupon={handleBookWithCoupon}
                onGoToWheel={() => setCurrentView('wheel')}
                onGoToQuiz={() => setCurrentView('quiz')}
              />
            )}

            {/* Quiz & Challenges Section */}
            {currentView === 'quiz' && (
              <div className="max-w-4xl mx-auto px-4">
                {/* Internal sub-switch between challenge quiz and questions bank */}
                <div className="flex items-center justify-between gap-3 mb-6 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm max-w-md mx-auto">
                  <button
                    onClick={() => setQuizSubTab('challenge')}
                    className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                      quizSubTab === 'challenge'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    بدء مسابقة التحدي
                  </button>
                  <button
                    onClick={() => setQuizSubTab('bank')}
                    className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      quizSubTab === 'bank'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>بنك الـ 152 سؤالاً</span>
                  </button>
                </div>

                {quizSubTab === 'challenge' ? (
                  <QuizView
                    onBookWithCoupon={handleBookWithCoupon}
                    onExploreBank={() => setQuizSubTab('bank')}
                  />
                ) : (
                  <QuestionBankView />
                )}
              </div>
            )}
          </main>
        </div>
      )}

      {/* Rewards & Coupons Modal (Accessible from inside all sections) */}
      {showCouponsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-right">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-2xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-5">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Tag className="w-5 h-5 text-emerald-600" />
                  <span>كوبونات وجوائز AlloVap الخاصة بك</span>
                </h3>
                <p className="text-xs text-slate-500">صلاحية محددة بـ 7 أيام من تاريخ الإصدار</p>
              </div>
              <button
                onClick={() => setShowCouponsModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {couponsList.length === 0 ? (
              <div className="text-center py-10">
                <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-bold text-slate-700 dark:text-slate-300 mb-1">
                  لا توجد لديك كوبونات نشطة حالياً
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mb-6">
                  دوّر عجلة الحظ، أو العب لعبة التنظيف، أو أجب عن الأسئلة لتربح كوبون تخفيض فوري!
                </p>
                <button
                  onClick={() => {
                    setShowCouponsModal(false);
                    setCurrentView('wheel');
                  }}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-blue-600 hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  دوّر عجلة الحظ الآن
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {couponsList.map(c => (
                  <CouponCard
                    key={c.id}
                    coupon={c}
                    onBookWithCoupon={(code) => {
                      handleBookWithCoupon(code);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Booking Modal (Accessible from inside all sections) */}
      {showBookingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-right">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-4xl w-full shadow-2xl relative max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setShowBookingModal(false)}
              className="absolute left-6 top-6 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>

            <BookingSection
              initialCouponCode={bookingCouponCode}
              onSuccessNavigate={() => setShowBookingModal(false)}
            />
          </div>
        </div>
      )}

      {/* Admin Portal Modal */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-right">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-6xl w-full shadow-2xl relative max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setShowAdminModal(false)}
              className="absolute left-6 top-6 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>

            <AdminPortal />
          </div>
        </div>
      )}
    </div>
  );
}
