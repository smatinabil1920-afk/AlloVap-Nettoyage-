import React, { useState } from 'react';
import { Sparkles, ArrowLeft, Sun, Moon, Smartphone, Download, Check } from 'lucide-react';
import { AndroidInstallModal } from './AndroidInstallModal';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { haptic } from '../utils/haptics';

interface ThreeChoicesHomeProps {
  onSelectChoice: (choice: 'wheel' | 'game' | 'quiz') => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const ThreeChoicesHome: React.FC<ThreeChoicesHomeProps> = ({
  onSelectChoice,
  darkMode,
  setDarkMode
}) => {
  const [showInstallModal, setShowInstallModal] = useState(false);
  const { isStandalone, isInstalled } = usePWAInstall();

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50/60 via-white to-emerald-50/40 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex flex-col justify-between text-right transition-colors">
      {/* Top Simple Bar: Logo & Android App & Theme switch */}
      <header className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-600 via-sky-600 to-emerald-500 flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-black tracking-tight text-slate-900 dark:text-white leading-none">
              Allo<span className="text-emerald-600 dark:text-emerald-400">Vap</span>
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1">
              تنظيف وتطهير بالبخار الاحترافي في تونس
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Android App Button */}
          <button
            onClick={() => {
              haptic.light();
              setShowInstallModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer"
            title="تثبيت تطبيق AlloVap على أندرويد"
          >
            {isStandalone || isInstalled ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span className="hidden sm:inline">مُثبت على Android</span>
                <span className="sm:hidden">مُثبت</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
                <span>تطبيق Android</span>
                <span className="hidden sm:inline-block px-1.5 py-0.2 bg-emerald-600 text-white rounded-md text-[10px]">
                  تثبيت
                </span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              haptic.light();
              setDarkMode(!darkMode);
            }}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="تبديل المظهر"
          >
            {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Main Container: Welcome message & Exactly Three Main Choices */}
      <main className="max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-4 sm:py-8 flex-1 flex flex-col justify-center">
        {/* Friendly Tunisian Arabic Welcome Message */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 dark:text-white mb-3 tracking-tight">
            عسلامة ومرحباً بيك في <span className="text-transparent bg-clip-text bg-gradient-to-l from-blue-600 to-emerald-600">AlloVap</span>! 🇹🇳
          </h1>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            اختار تجربتك المفضلة من بين الخيارات الثلاثة التالية، استمتع باللعب واربح كوبونات تخفيض حقيقية وصالحة لـ 7 أيام لصالون دارك أو كرهبتك.
          </p>
        </div>

        {/* EXACTLY THREE LARGE, ATTRACTIVE, CLICKABLE MAIN CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 max-w-5xl mx-auto w-full">
          {/* Card 1: 🎡 عجلة الحظ */}
          <div
            onClick={() => onSelectChoice('wheel')}
            className="group relative bg-white dark:bg-slate-900 rounded-3xl border-2 border-blue-200/80 dark:border-blue-900/60 p-7 sm:p-8 shadow-lg hover:shadow-2xl hover:border-blue-500 dark:hover:border-blue-400 transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden transform hover:-translate-y-1"
          >
            {/* Top gradient glow */}
            <div className="absolute top-0 right-0 left-0 h-2 bg-gradient-to-l from-blue-600 via-sky-500 to-indigo-600" />
            
            <div>
              <div className="w-16 h-16 rounded-3xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 flex items-center justify-center text-3xl mb-6 shadow-sm group-hover:scale-110 transition-transform">
                🎡
              </div>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-blue-600 dark:text-sky-400 font-mono">الخيار 1</span>
                <span className="w-1.5 h-1.5 rounded-full bg-blue-300 dark:bg-blue-700" />
                <span className="text-xs text-slate-400 font-semibold">تخفيضات فورية</span>
              </div>

              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-3 group-hover:text-blue-600 dark:group-hover:text-sky-400 transition-colors">
                عجلة الحظ
              </h2>

              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                دوّر العجلة التفاعلية وجرّب حظك! اربح تخفيضات فورية من 5% إلى 15% أو غسيل ستائر مجاني لصالون دارك.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold text-blue-600 dark:text-sky-400 group-hover:translate-x-[-4px] transition-transform flex items-center gap-1.5">
                <span>دوّر العجلة الآن</span>
                <ArrowLeft className="w-4 h-4" />
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                5 جوائز متاحة
              </span>
            </div>
          </div>

          {/* Card 2: 🫧 لعبة التنظيف */}
          <div
            onClick={() => onSelectChoice('game')}
            className="group relative bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-200/80 dark:border-emerald-900/60 p-7 sm:p-8 shadow-lg hover:shadow-2xl hover:border-emerald-500 dark:hover:border-emerald-400 transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden transform hover:-translate-y-1"
          >
            {/* Top gradient glow */}
            <div className="absolute top-0 right-0 left-0 h-2 bg-gradient-to-l from-emerald-500 via-teal-500 to-green-600" />

            <div>
              <div className="w-16 h-16 rounded-3xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center text-3xl mb-6 shadow-sm group-hover:scale-110 transition-transform">
                🫧
              </div>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-mono">الخيار 2</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 dark:bg-emerald-700" />
                <span className="text-xs text-slate-400 font-semibold">تفاعل وتشويق</span>
              </div>

              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-3 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                لعبة التنظيف
              </h2>

              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                استعمل فرد البخار الافتراضي وامسح الدهون والأوساخ في 5 مستويات واقعية (صالون، سيارة، ماطلا، ستائر، وكراسي)!
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 group-hover:translate-x-[-4px] transition-transform flex items-center gap-1.5">
                <span>ابدأ اللعبة الآن</span>
                <ArrowLeft className="w-4 h-4" />
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                5 مستويات ممتعة
              </span>
            </div>
          </div>

          {/* Card 3: 🧠 الأسئلة والتحديات */}
          <div
            onClick={() => onSelectChoice('quiz')}
            className="group relative bg-white dark:bg-slate-900 rounded-3xl border-2 border-indigo-200/80 dark:border-indigo-900/60 p-7 sm:p-8 shadow-lg hover:shadow-2xl hover:border-indigo-500 dark:hover:border-indigo-400 transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden transform hover:-translate-y-1"
          >
            {/* Top gradient glow */}
            <div className="absolute top-0 right-0 left-0 h-2 bg-gradient-to-l from-indigo-600 via-blue-500 to-sky-600" />

            <div>
              <div className="w-16 h-16 rounded-3xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center text-3xl mb-6 shadow-sm group-hover:scale-110 transition-transform">
                🧠
              </div>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 font-mono">الخيار 3</span>
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-300 dark:bg-indigo-700" />
                <span className="text-xs text-slate-400 font-semibold">ثقافة وتوعية</span>
              </div>

              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-3 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                الأسئلة والتحديات
              </h2>

              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                اختبر معلوماتك في 152 سؤالاً بالدارجة التونسية حول النظافة الصحية، واكتشف نصائح مفيدة واربح كوبوناً بنسبة سكورك!
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-[-4px] transition-transform flex items-center gap-1.5">
                <span>ادخل المسابقة الآن</span>
                <ArrowLeft className="w-4 h-4" />
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                152 سؤالاً بالدارجة
              </span>
            </div>
          </div>
        </div>

        {/* Android PWA Quick Banner (subtle and friendly) */}
        {!isStandalone && !isInstalled && (
          <div className="max-w-xl mx-auto mt-8 w-full">
            <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-cyan-950/40 border border-emerald-500/30 rounded-2xl p-3 sm:p-4 flex items-center justify-between gap-3 text-xs shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    استعمل AlloVap كتطبيق رسمي على هاتفك Android
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    بدون تحميل من المتجر • شاشة كاملة وسرعة فائقة
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  haptic.medium();
                  setShowInstallModal(true);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 transition-colors shadow-sm cursor-pointer"
              >
                تثبيت التطبيق
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Quiet Brand Footer */}
      <footer className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 text-center text-xs text-slate-500 dark:text-slate-500 border-t border-slate-200/60 dark:border-slate-800/60">
        <p>
          © {new Date().getFullYear()} AlloVap Tunisie. الكوبونات صالحة لـ 7 أيام لحجز خدمات التنظيف بالبخار.
        </p>
      </footer>

      {/* Android Install Modal */}
      <AndroidInstallModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
      />
    </div>
  );
};
