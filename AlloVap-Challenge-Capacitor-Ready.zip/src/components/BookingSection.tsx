import React, { useState, useEffect } from 'react';
import { findCouponByCode, saveBooking } from '../utils/couponManager';
import { BookingSubmission, Coupon } from '../types';
import { 
  Calendar, 
  CheckCircle2, 
  Tag, 
  AlertCircle, 
  Phone, 
  User, 
  MapPin, 
  FileText, 
  Check, 
  Clock,
  Sparkles
} from 'lucide-react';

interface BookingSectionProps {
  initialCouponCode?: string;
  onSuccessNavigate?: () => void;
}

const SERVICES = [
  {
    id: 'salon_tissu',
    title: 'تنظيف وتطهير صالون قماشي (5 إلى 7 مقاعد)',
    description: 'غسيل عميق بالحقن والاستخراج الصناعي وتطهير بالبخار الجاف وإزالة الروائح والرواسب.',
    basePrice: 140,
    unit: 'دينار تونسي',
    duration: '2 إلى 3 ساعات'
  },
  {
    id: 'salon_cuir',
    title: 'عناية ملكية لصالون جلدي (Salon Cuir)',
    description: 'تنظيف بخاري لطيف، إزالة الدهون المتراكمة، مع تطبيق بلسم حماية وتغذية فرنسي فاخر.',
    basePrice: 180,
    unit: 'دينار تونسي',
    duration: '2 إلى 3 ساعات'
  },
  {
    id: 'voiture_complet',
    title: 'باقة تنظيف صالون السيارة بالكامل (Habitacle Complet)',
    description: 'المقاعد، الأرضيات، الموكيت، الأبواب، السقف، ولوحة القيادة بالبخار واستخراج الدهون والأملاح.',
    basePrice: 130,
    unit: 'دينار تونسي',
    duration: 'ساعتان ونصف'
  },
  {
    id: 'matelas_2p',
    title: 'تطهير عميق لمرتبة نوم شخصين (Matelas 2 Places)',
    description: 'شفط واستخراج قوي لمخلفات عث الغبار والتعرق من الوجهين مع بخار جاف معقم.',
    basePrice: 75,
    unit: 'دينار تونسي',
    duration: 'ساعة ونصف'
  },
  {
    id: 'tapis_moquette',
    title: 'غسيل زرابي فاخرة وموكيت في مكانها (Tapis & Moquette)',
    description: 'حقن واستخراج فوري للألياف العميقة، استرجاع الألوان الأصلية مع جفاف سريع وآمن.',
    basePrice: 90,
    unit: 'دينار تونسي',
    duration: 'ساعتان'
  },
  {
    id: 'rideaux_sur_place',
    title: 'تنظيف الستائر في مكانها بالبخار الجاف (Rideaux sur place)',
    description: 'إزالة الغبار والروائح وفرد تجاعيد القماش دون الحاجة للفك أو إعادة التركيب.',
    basePrice: 80,
    unit: 'دينار تونسي',
    duration: 'ساعة ونصف'
  }
];

const TUNISIAN_CITIES = [
  'تونس (العاصمة)',
  'أريانة (المنزه، النصر، سكرة...)',
  'بن عروس (رادس، الزهراء، المروج...)',
  'منوبة (الدندان، وادي الليل...)',
  'نابل والحمامات',
  'سوسة والمنستير',
  'بنزرت',
  'صفاقس'
];

export const BookingSection: React.FC<BookingSectionProps> = ({
  initialCouponCode = '',
  onSuccessNavigate
}) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICES[0].id);
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('+216 ');
  const [city, setCity] = useState(TUNISIAN_CITIES[0]);
  const [address, setAddress] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [notes, setNotes] = useState('');

  // Coupon state
  const [couponInput, setCouponInput] = useState(initialCouponCode);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Booking result
  const [bookingDone, setBookingDone] = useState<BookingSubmission | null>(null);

  useEffect(() => {
    if (initialCouponCode) {
      setCouponInput(initialCouponCode);
      verifyCoupon(initialCouponCode);
    }
  }, [initialCouponCode]);

  const verifyCoupon = (code: string) => {
    setCouponError('');
    setCouponSuccess('');
    if (!code.trim()) {
      setAppliedCoupon(null);
      return;
    }

    const c = findCouponByCode(code);
    if (!c) {
      setAppliedCoupon(null);
      setCouponError('رمز الكوبون غير صحيح أو غير مسجل في النظام.');
      return;
    }

    if (c.status === 'used') {
      setAppliedCoupon(null);
      setCouponError('هذا الكوبون تم استعماله مسبقاً (صالح لمرة واحدة فقط).');
      return;
    }

    if (c.status === 'expired') {
      setAppliedCoupon(null);
      setCouponError('انتهت صلاحية هذا الكوبون (مرت 7 أيام من تاريخ إصداره).');
      return;
    }

    setAppliedCoupon(c);
    setCouponSuccess(`تم التحقق بنجاح! خصم بقيمة %${c.discountPercentage} صالح لحجزك.`);
  };

  const selectedService = SERVICES.find(s => s.id === selectedServiceId) || SERVICES[0];
  const discountPercent = appliedCoupon ? appliedCoupon.discountPercentage : 0;
  const originalPrice = selectedService.basePrice;
  const discountAmount = Math.round((originalPrice * discountPercent) / 100);
  const finalPrice = originalPrice - discountAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim() || !phone.trim() || !address.trim() || !preferredDate) {
      alert('الرجاء إكمال جميع البيانات المطلوبة لتأكيد الموعد.');
      return;
    }

    const newBooking: BookingSubmission = {
      id: `BK-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName,
      phone,
      city,
      address,
      serviceType: selectedService.title,
      preferredDate,
      couponCode: appliedCoupon ? appliedCoupon.code : undefined,
      originalPrice,
      discountAmount,
      finalPrice,
      notes,
      createdAt: new Date().toISOString(),
      status: 'confirmed'
    };

    saveBooking(newBooking);
    setBookingDone(newBooking);
  };

  if (bookingDone) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 text-right animate-fade-in">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-10 shadow-lg text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-6">
            <Check className="w-8 h-8" />
          </div>

          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
            تم تسجيل حجزك بنجاح!
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mb-6">
            سيتصل بك فريق إدارة AlloVap في أقرب وقت لتأكيد التوقيت الدقيق وإرسال الفريق الفني لعنوانك.
          </p>

          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 max-w-md mx-auto text-right text-xs space-y-2 mb-6">
            <div className="flex justify-between">
              <span className="text-slate-500">رقم الحجز المرجعي:</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">{bookingDone.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">الحريف:</span>
              <span className="font-bold text-slate-900 dark:text-white">{bookingDone.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">الخدمة:</span>
              <span className="font-bold text-slate-900 dark:text-white">{bookingDone.serviceType}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">التاريخ المفضل:</span>
              <span className="font-bold text-slate-900 dark:text-white">{bookingDone.preferredDate}</span>
            </div>
            {bookingDone.couponCode && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                <span>الكوبون المعتمد:</span>
                <span className="font-mono font-bold">{bookingDone.couponCode} (-{bookingDone.discountAmount} DT)</span>
              </div>
            )}
            <div className="flex justify-between border-t border-slate-200 dark:border-slate-700 pt-2 text-sm font-black text-slate-900 dark:text-white">
              <span>السعر الإجمالي بعد الخصم:</span>
              <span className="text-emerald-600 dark:text-emerald-400">{bookingDone.finalPrice} دينار تونسي</span>
            </div>
          </div>

          <button
            onClick={() => {
              setBookingDone(null);
              if (onSuccessNavigate) onSuccessNavigate();
            }}
            className="px-6 py-2.5 rounded-xl font-bold text-sm text-white bg-slate-900 dark:bg-white dark:text-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            الرجوع إلى الصفحة الرئيسية
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 text-right">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="max-w-2xl mb-8">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-sky-400 bg-blue-50 dark:bg-blue-950/40 px-3 py-1 rounded-full mb-3">
            <Calendar className="w-3.5 h-3.5" />
            حجز خدمة AlloVap الميدانية في تونس
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
            احجز موعد التنظيف واستفد من كوبون التخفيض
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            فريق AlloVap يتنقل بكامل تجهيزاته الصناعية إلى منزلك أو مقر عملك لتقديم تنظيف وتطهير بالبخار الجاف والاستخراج وفق أعلى المعايير.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Step 1: Service Selection */}
          <div>
            <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">
              1. اختر الخدمة المطلوبة:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SERVICES.map(srv => {
                const isSelected = selectedServiceId === srv.id;
                return (
                  <button
                    key={srv.id}
                    type="button"
                    onClick={() => setSelectedServiceId(srv.id)}
                    className={`p-4 rounded-2xl border-2 text-right transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/30'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {srv.title}
                        </span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
                        {srv.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
                      <span className="text-slate-400 font-medium">المدة: {srv.duration}</span>
                      <span className="font-bold text-slate-900 dark:text-emerald-400">
                        {srv.basePrice} DT
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Coupon code verification (Rule 1: Usable only for a real AlloVap service booking) */}
          <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl p-5 border border-slate-200 dark:border-slate-700">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2 mb-2">
              <Tag className="w-4 h-4 text-emerald-600" />
              <span>عندك كوبون تخفيض من مسابقة AlloVap؟</span>
            </label>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              كل كوبون صالح لمدة 7 أيام ويتم تفعيله مرة واحدة لخدمة حقيقية.
            </p>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={couponInput}
                onChange={e => setCouponInput(e.target.value.toUpperCase())}
                placeholder="مثال: AV-7D-10P-XXXX"
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-mono uppercase tracking-wider text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-right"
              />
              <button
                type="button"
                onClick={() => verifyCoupon(couponInput)}
                className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-emerald-600 hover:bg-emerald-700 transition-colors cursor-pointer shrink-0"
              >
                تطبيق الكوبون
              </button>
            </div>

            {couponError && (
              <p className="text-xs font-semibold text-rose-600 dark:text-rose-400 mt-2 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                {couponError}
              </p>
            )}
            {couponSuccess && (
              <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mt-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {couponSuccess}
              </p>
            )}
          </div>

          {/* Pricing Summary */}
          <div className="p-4 rounded-2xl bg-gradient-to-l from-sky-50 to-emerald-50 dark:from-slate-800 dark:to-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs">
            <div className="flex justify-between py-1 text-slate-600 dark:text-slate-300">
              <span>السعر الأصلي للخدمة:</span>
              <span className="font-bold">{originalPrice} DT</span>
            </div>
            {appliedCoupon && (
              <div className="flex justify-between py-1 text-emerald-700 dark:text-emerald-400 font-bold">
                <span>تخفيض الكوبون (%{appliedCoupon.discountPercentage}):</span>
                <span>-{discountAmount} DT</span>
              </div>
            )}
            <div className="flex justify-between pt-2 border-t border-emerald-200 dark:border-emerald-800 text-sm sm:text-base font-black text-slate-900 dark:text-white">
              <span>المبلغ الإجمالي للدفع عند الإنجاز:</span>
              <span className="text-emerald-600 dark:text-emerald-400">{finalPrice} دينار تونسي</span>
            </div>
          </div>

          {/* Step 3: Customer Information */}
          <div>
            <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">
              3. بيانات الاتصال والعنوان في تونس:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  الاسم واللقب *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    placeholder="مثال: محمد الطرابلسي"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  رقم الهاتف التونسي *
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+216 98 123 456"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right font-mono"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  الولاية / المنطقة *
                </label>
                <select
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right cursor-pointer"
                >
                  {TUNISIAN_CITIES.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  التاريخ المفضل للتدخل *
                </label>
                <div className="relative">
                  <input
                    type="date"
                    required
                    value={preferredDate}
                    onChange={e => setPreferredDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right cursor-pointer"
                  />
                  <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>
            </div>

            <div className="mt-4">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                العنوان التفصيلي (الشارع، الإقامة، رقم الباب...) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="مثال: نهج الهادي نويرة، إقامة الفل، شقة 4، النصر 2"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right"
                />
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            <div className="mt-4">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                ملاحظات إضافية (نوع القماش، بقع سابقة، مواقف السيارات...)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="اكتب أي توضيح ترغب في إعلام الفريق الفني به مسبقاً..."
                className="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right resize-none"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              الدفع يكون نقداً أو بالتحويل البنكي بعد انتهاء الخدمة ومعاينتك التامة للنتيجة.
            </span>

            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-md transition-all cursor-pointer active:scale-95"
            >
              تأكيد وإرسال طلب الحجز
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
