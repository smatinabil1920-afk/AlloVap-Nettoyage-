import React, { useState } from 'react';
import { 
  Home, 
  Tag, 
  HelpCircle, 
  Wrench, 
  MessageSquare, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight,
  X,
  Phone,
  Smartphone
} from 'lucide-react';
import { AndroidInstallModal } from './AndroidInstallModal';
import { haptic } from '../utils/haptics';

interface SectionNavProps {
  currentSection: 'wheel' | 'game' | 'quiz';
  onReturnHome: () => void;
  onOpenBooking: () => void;
  onOpenCoupons: () => void;
  onOpenAdmin: () => void;
}

export const SectionNav: React.FC<SectionNavProps> = ({
  currentSection,
  onReturnHome,
  onOpenBooking,
  onOpenCoupons,
  onOpenAdmin
}) => {
  const [showInstructions, setShowInstructions] = useState(false);
  const [showServicesModal, setShowServicesModal] = useState(false);
  const [showAndroidModal, setShowAndroidModal] = useState(false);

  const getSectionTitle = () => {
    switch (currentSection) {
      case 'wheel':
        return { title: 'عجلة الحظ', icon: '🎡' };
      case 'game':
        return { title: 'لعبة التنظيف', icon: '🫧' };
      case 'quiz':
        return { title: 'الأسئلة والتحديات', icon: '🧠' };
    }
  };

  const getInstructionsText = () => {
    switch (currentSection) {
      case 'wheel':
        return {
          title: 'طريقة وقواعد عجلة الحظ',
          items: [
            'اضغط على زر "دوّر عجلة الحظ الآن" لبدء دوران العجلة.',
            'العجلة تدور بدورات كاملة وتقف بدقة متناهية على القطاع الرابح.',
            'الجوائز تتراوح بين تخفيضات 5%، 10%، 15%، وغسيل ستائر مجاني، أو حظ أوفر.',
            'كل كوبون رابح فريد وصالح لمدة 7 أيام بالضبط ويستعمل مرة واحدة لحجز خدمة حقيقية لدى AlloVap.'
          ]
        };
      case 'game':
        return {
          title: 'طريقة وقواعد لعبة التنظيف بالبخار',
          items: [
            'حرك الماوس أو إصبعك فوق السطح المتسخ لمحاكاة فرد البخار والاستخراج.',
            'نظف 85% على الأقل من السطح قبل انتهاء العداد الزمني (40 ثانية).',
            'اللعبة تحتوي على 5 مستويات واقعية: صالونات، سيارات، مراتب، ستائر، وكراسي.',
            'إكمال المستويات الخمسة يكافئك بكوبون تخفيض 10% صالح لـ 7 أيام.'
          ]
        };
      case 'quiz':
        return {
          title: 'طريقة وقواعد مسابقة الأسئلة والتحديات',
          items: [
            'أجب عن الأسئلة المكتوبة بالدارجة التونسية في مجالات النظافة والتطهير.',
            'بعد كل إجابة، ستكتشف التفسير العلمي والنصيحة الصحية وطريقة مساعدة AlloVap.',
            'الأسئلة تلتزم بالدقة العلمية (عدم ادعاء 100% تعقيم، واقعية إزالة البقع، وتفوق المعدات الصناعية).',
            'في النهاية يتم احتساب تخفيض من 1% إلى 10% بحسب نتيجتك، ويصدر لك كوبون فريد صالح لـ 7 أيام.'
          ]
        };
    }
  };

  const instructions = getInstructionsText();
  const info = getSectionTitle();

  const handleWhatsAppBooking = () => {
    const text = encodeURIComponent('عسلامة فريق AlloVap، نحب نستفسر على موعد تنظيف بالبخار ونستعمل كوبون التخفيض متاعي.');
    window.open(`https://api.whatsapp.com/send?phone=21698450120&text=${text}`, '_blank');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Right: Return to Homepage & Section Badge */}
          <div className="flex items-center gap-3">
            <button
              onClick={onReturnHome}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
            >
              <ArrowRight className="w-4 h-4 text-emerald-600" />
              <span>الرئيسية</span>
            </button>

            <div className="hidden sm:flex items-center gap-2">
              <span className="text-xl">{info.icon}</span>
              <span className="font-black text-slate-900 dark:text-white text-base">
                {info.title}
              </span>
            </div>
          </div>

          {/* Center / Navigation Links for this Section */}
          <nav className="flex items-center gap-1.5 sm:gap-3 text-xs font-semibold text-slate-600 dark:text-slate-300">
            {/* Game / Section Instructions */}
            <button
              onClick={() => setShowInstructions(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
              <span className="hidden md:inline">قواعد اللعب</span>
            </button>

            {/* Coupons & Rewards */}
            <button
              onClick={onOpenCoupons}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-emerald-700 dark:text-emerald-400 font-bold"
            >
              <Tag className="w-3.5 h-3.5 text-emerald-600" />
              <span>الكوبونات والجوائز</span>
            </button>

            {/* AlloVap Services & Pricing */}
            <button
              onClick={() => setShowServicesModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Wrench className="w-3.5 h-3.5 text-teal-500" />
              <span className="hidden md:inline">خدمات AlloVap</span>
            </button>

            {/* Direct WhatsApp Booking */}
            <button
              onClick={handleWhatsAppBooking}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-white bg-[#25D366] hover:bg-[#20ba5a] transition-all cursor-pointer shadow-sm active:scale-95"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">حجز واتساب</span>
            </button>

            {/* Online Booking Button */}
            <button
              onClick={onOpenBooking}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all cursor-pointer shadow-sm"
            >
              <span>حجز مباشر بالكوبون</span>
            </button>
          </nav>

          {/* Left: Brand Wordmark + Admin link + Android button */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => {
                haptic.light();
                setShowAndroidModal(true);
              }}
              className="p-1.5 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
              title="تثبيت تطبيق أندرويد"
            >
              <Smartphone className="w-4 h-4" />
              <span className="text-[11px] font-bold hidden lg:inline">تطبيق Android</span>
            </button>

            <button
              onClick={onOpenAdmin}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors cursor-pointer"
              title="لوحة الإدارة"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>

            <button
              onClick={onReturnHome}
              className="flex items-center gap-1.5 cursor-pointer text-right"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-emerald-500 flex items-center justify-center text-white">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-sm font-black text-slate-900 dark:text-white hidden sm:inline">
                Allo<span className="text-emerald-600">Vap</span>
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Instructions Modal */}
      {showInstructions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-right">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-lg w-full shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-blue-600" />
                <span>{instructions.title}</span>
              </h3>
              <button
                onClick={() => setShowInstructions(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 mb-6">
              {instructions.items.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                  <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="leading-relaxed">{item}</p>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setShowInstructions(false)}
                className="px-6 py-2 rounded-xl font-bold text-xs sm:text-sm text-white bg-slate-900 dark:bg-white dark:text-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                فهمت، واصل
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AlloVap Services Modal */}
      {showServicesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-right">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-2xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-emerald-600" />
                  <span>خدمات التنظيف بالبخار من AlloVap</span>
                </h3>
                <p className="text-xs text-slate-500">تنقل على عين المكان في تونس الكبرى وكافة الولايات</p>
              </div>
              <button
                onClick={() => setShowServicesModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 text-xs">
              <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <span className="font-bold text-slate-900 dark:text-white block mb-1">
                  1. تنظيف صالونات القماش والمخمل
                </span>
                <p className="text-slate-500 mb-2 leading-relaxed">
                  حقن واستخراج صناعي يزيل أصعب البقع والدهون دون إشباع الإسفنج بالماء.
                </p>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">ابتداءً من 140 دينار</span>
              </div>

              <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <span className="font-bold text-slate-900 dark:text-white block mb-1">
                  2. عناية ملكية لصالونات الجلد
                </span>
                <p className="text-slate-500 mb-2 leading-relaxed">
                  بخار معتدل ومسح ميكروفايبر مع وضع كريم مغذٍ وواقٍ يمنع التشقق.
                </p>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">ابتداءً من 180 دينار</span>
              </div>

              <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <span className="font-bold text-slate-900 dark:text-white block mb-1">
                  3. تنظيف داخل السيارة بالكامل
                </span>
                <p className="text-slate-500 mb-2 leading-relaxed">
                  المقاعد، الأرضيات، الموكيت، الأبواب، السقف وفتحات التهوئة.
                </p>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">ابتداءً من 130 دينار</span>
              </div>

              <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
                <span className="font-bold text-slate-900 dark:text-white block mb-1">
                  4. غسيل وتطهير المراتب (Matelas)
                </span>
                <p className="text-slate-500 mb-2 leading-relaxed">
                  شفط قوي واستخراج لمخلفات عث الغبار وخلايا الجلد والعرق.
                </p>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">ابتداءً من 75 دينار</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs mb-4">
              <span className="text-emerald-800 dark:text-emerald-300 font-semibold">
                هل لديك كوبون من المسابقة؟ يمكنك خصم قيمته مباشرة من هذه الأسعار!
              </span>
              <button
                onClick={() => {
                  setShowServicesModal(false);
                  onOpenBooking();
                }}
                className="px-4 py-1.5 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors cursor-pointer shrink-0"
              >
                احجز الآن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Android Install Modal */}
      <AndroidInstallModal
        isOpen={showAndroidModal}
        onClose={() => setShowAndroidModal(false)}
      />
    </header>
  );
};
