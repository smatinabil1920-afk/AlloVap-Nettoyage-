import React, { useState, useEffect, useRef } from 'react';
import { CleaningLevel, Coupon } from '../types';
import { createGameCoupon } from '../utils/couponManager';
import { CouponCard } from './CouponCard';
import { SocialShareCard } from './SocialShareCard';
import { haptic } from '../utils/haptics';
import { 
  Sparkles, 
  Clock, 
  Trophy, 
  RotateCcw, 
  ArrowLeft, 
  CheckCircle2, 
  ShieldCheck, 
  Award,
  Zap
} from 'lucide-react';

const CLEANING_LEVELS: CleaningLevel[] = [
  {
    id: 1,
    title: 'المستوى 1: صالون وأريكة قماشية فاخرة',
    subtitle: 'إزالة الغبار والشحوم وتجديد نسيج الصالون بالبخار الجاف والشفط',
    image: '/src/assets/images/allovap_hero_steam_1793672263962.jpg',
    targetCleanPercent: 85,
    timeLimitSeconds: 40,
    facts: 'صالون البيت يجمع أكثر من 80% من الأتربة اليومية؛ البخار يذوب الدهون ويسحبها دون تبليل الإسفنج.'
  },
  {
    id: 2,
    title: 'المستوى 2: مقاعد وصالون السيارة (Habitacle)',
    subtitle: 'استخراج الأملاح وبقع العرق والقهوة من مقاعد وقماش السيارة',
    image: '/src/assets/images/allovap_car_interior_1793672265598.jpg',
    targetCleanPercent: 85,
    timeLimitSeconds: 40,
    facts: 'قمرة السيارة تتعرض لحرارة محبوسة وعرق؛ التنظيف بالحقن والاستخراج يعيد إليها رائحة ونقاء الوكالة.'
  },
  {
    id: 3,
    title: 'المستوى 3: مرتبة نوم شخصين (Matelas)',
    subtitle: 'تطهير عميق من عث الغبار (Acariens) وبقع التعرق لبيئة نوم صحية',
    image: '/src/assets/images/allovap_mattress_clean_1793672264736.jpg',
    targetCleanPercent: 85,
    timeLimitSeconds: 40,
    facts: 'الإنسان يفقد 1.5 غرام من خلايا الجلد ليلة النوم؛ تنظيف الماطلا بالبخار يريحك من الحساسية والكحة.'
  },
  {
    id: 4,
    title: 'المستوى 4: الستائر المعلقة (Rideaux)',
    subtitle: 'تنظيف الستائر في مكانها بالبخار وفرد تجاعيد القماش دون فك',
    image: '/src/assets/images/allovap_curtains_clean_1793711222753.jpg',
    targetCleanPercent: 85,
    timeLimitSeconds: 40,
    facts: 'الستائر هي أول مصفاة لدخان الشارع؛ تنظيفها بالبخار الجاف sur place يوفر عليك عناء الفك والتركيب.'
  },
  {
    id: 5,
    title: 'المستوى 5: كراسي السفرة والمكتب (Chaises)',
    subtitle: 'تفكيك بقع الأكل المترسبة والزيوت من كراسي القماش والجلد',
    image: '/src/assets/images/allovap_chairs_clean_1793711221844.jpg',
    targetCleanPercent: 85,
    timeLimitSeconds: 40,
    facts: 'كراسي السفرة والعمل تحتاج معاملة ميكانيكية دقيقة تحمي الخياطة والألوان وتمنع تكون الهالات.'
  }
];

interface CleaningGameProps {
  onBookWithCoupon: (code: string) => void;
  onGoToWheel: () => void;
  onGoToQuiz: () => void;
}

export const CleaningGame: React.FC<CleaningGameProps> = ({
  onBookWithCoupon,
  onGoToWheel,
  onGoToQuiz
}) => {
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [cleanPercent, setCleanPercent] = useState(0);
  const [timeLeft, setTimeLeft] = useState(40);
  const [totalScore, setTotalScore] = useState(0);
  const [levelWon, setLevelWon] = useState(false);
  const [levelLost, setLevelLost] = useState(false);
  const [gameFinished, setGameFinished] = useState(false);
  const [wonCoupon, setWonCoupon] = useState<Coupon | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isMouseDownRef = useRef(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSampleTimeRef = useRef<number>(0);

  const currentLevel = CLEANING_LEVELS[currentLevelIdx];

  // Initialize dirty canvas overlay
  const initDirtyCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, width, height);

    // Draw dusty translucent grime layer
    ctx.fillStyle = 'rgba(78, 59, 45, 0.72)';
    ctx.fillRect(0, 0, width, height);

    // Add noise and grease spots
    ctx.fillStyle = 'rgba(45, 30, 20, 0.85)';
    for (let i = 0; i < 60; i++) {
      const rx = Math.random() * width;
      const ry = Math.random() * height;
      const rr = 12 + Math.random() * 35;
      ctx.beginPath();
      ctx.arc(rx, ry, rr, 0, Math.PI * 2);
      ctx.fill();
    }

    // Add watermark / stains
    ctx.strokeStyle = 'rgba(100, 70, 50, 0.6)';
    ctx.lineWidth = 4;
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.arc(Math.random() * width, Math.random() * height, 30 + Math.random() * 40, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Reset progress
    setCleanPercent(0);
  };

  // Start Level
  const startLevel = (lvlIndex: number) => {
    setCurrentLevelIdx(lvlIndex);
    setLevelWon(false);
    setLevelLost(false);
    setTimeLeft(CLEANING_LEVELS[lvlIndex].timeLimitSeconds);
    setIsPlaying(true);

    setTimeout(() => {
      initDirtyCanvas();
    }, 100);
  };

  // Timer countdown
  useEffect(() => {
    if (!isPlaying || levelWon || levelLost || gameFinished) return;

    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setLevelLost(true);
          setIsPlaying(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, levelWon, levelLost, gameFinished]);

  // Handle Clean Percentage Calculation
  const checkCleanliness = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    // Downsample for fast 60fps sampling
    const imgData = ctx.getImageData(0, 0, width, height).data;
    let transparentPixels = 0;
    const step = 16; // sample every 16th pixel for speed
    let totalSampled = 0;

    for (let i = 3; i < imgData.length; i += step * 4) {
      totalSampled++;
      if (imgData[i] < 30) {
        transparentPixels++;
      }
    }

    const pct = Math.min(100, Math.round((transparentPixels / totalSampled) * 100));
    setCleanPercent(pct);

    if (pct >= currentLevel.targetCleanPercent && !levelWon) {
      haptic.success();
      setLevelWon(true);
      setIsPlaying(false);
      const points = 200 + (timeLeft * 10);
      setTotalScore(prev => prev + points);

      // Check if all 5 levels completed
      if (currentLevelIdx >= CLEANING_LEVELS.length - 1) {
        // Game completed! Win 10% coupon
        const coupon = createGameCoupon(10, totalScore + points);
        setWonCoupon(coupon);
        setGameFinished(true);
      }
    }
  };

  // Steam clean sweep handler (Destination Out)
  const applySteamClean = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas || !isPlaying || levelWon || levelLost) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    // Erase dirty layer with soft circular brush
    ctx.globalCompositeOperation = 'destination-out';
    const gradient = ctx.createRadialGradient(x, y, 5, x, y, 38);
    gradient.addColorStop(0, 'rgba(0,0,0,1)');
    gradient.addColorStop(0.7, 'rgba(0,0,0,0.85)');
    gradient.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, 38, 0, Math.PI * 2);
    ctx.fill();

    // Sample progress throttled to 200ms
    const now = Date.now();
    if (now - lastSampleTimeRef.current > 200) {
      lastSampleTimeRef.current = now;
      checkCleanliness();
    }
  };

  // Next level
  const handleNextLevel = () => {
    if (currentLevelIdx + 1 < CLEANING_LEVELS.length) {
      startLevel(currentLevelIdx + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 text-right animate-fade-in">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm mb-6 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <span className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 px-3 py-1 rounded-full mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            لعبة التنظيف الافتراضية بالبخار
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
            نظف المفروشات بالبخار واربح كوبون 10%
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-xl">
            استعمل فرد البخار الافتراضي وامسح الأوساخ والدهون من الصالون والسيارة والماطلا والستائر والكراسي لتربح تخفيضاً حقيقياً!
          </p>
        </div>

        {/* Global Score & Progress Badge */}
        <div className="flex items-center gap-3">
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 text-center">
            <span className="text-[11px] text-slate-500 block mb-0.5 font-semibold">المستوى</span>
            <span className="font-mono text-xl font-black text-blue-600 dark:text-sky-400">
              {currentLevelIdx + 1} / 5
            </span>
          </div>
          <div className="bg-emerald-50 dark:bg-emerald-950/40 p-3.5 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-center">
            <span className="text-[11px] text-emerald-700 dark:text-emerald-300 block mb-0.5 font-semibold">النقاط</span>
            <span className="font-mono text-xl font-black text-emerald-700 dark:text-emerald-300">
              {totalScore}
            </span>
          </div>
        </div>
      </div>

      {/* Main Game Stage */}
      {!isPlaying && !levelWon && !levelLost && !gameFinished ? (
        /* Game Start Screen */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-md text-center">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-teal-500 to-blue-600 flex items-center justify-center text-white shadow-lg mb-6">
            <Zap className="w-10 h-10" />
          </div>

          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-3">
            مستعد لتجربة قوة البخار والاستخراج؟
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mb-8 leading-relaxed">
            مرر إصبعك أو الفأرة فوق الأسطح المتسخة واستمتع بإزالة الأوساخ بنسبة تفوق 85% في 5 مستويات واقعية لتربح كوبون تخفيض 10% صالح لـ 7 أيام.
          </p>

          {/* Level Previews */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-2xl mx-auto mb-8">
            {CLEANING_LEVELS.map((lvl, i) => (
              <div
                key={lvl.id}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 text-center"
              >
                <span className="text-xs font-bold text-slate-400 block mb-1">مستوى {i + 1}</span>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 line-clamp-1">
                  {lvl.title.split(':')[1] || lvl.title}
                </span>
              </div>
            ))}
          </div>

          <button
            onClick={() => startLevel(0)}
            className="px-10 py-4 rounded-2xl font-black text-base text-white bg-gradient-to-r from-emerald-500 via-teal-600 to-blue-600 hover:from-emerald-600 hover:to-blue-700 shadow-xl transition-all cursor-pointer active:scale-95"
          >
            ابدأ المستوى الأول الآن
          </button>
        </div>
      ) : gameFinished && wonCoupon ? (
        /* Game Victory Screen */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/40 p-8 sm:p-10 shadow-xl text-center animate-fade-in">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 to-emerald-500 flex items-center justify-center text-white shadow-lg mb-6">
            <Trophy className="w-10 h-10" />
          </div>

          <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-2">
            برافو! أكملت جميع المستويات الـ 5 بنجاح تام
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-lg mx-auto mb-6">
            أثبتّ مهارتك كبطل نظافة AlloVap! كافأناك بأعلى نسبة تخفيض (10%) صالحة لـ 7 أيام على خدماتنا الميدانية.
          </p>

          <div className="max-w-xl mx-auto my-6 text-right">
            <CouponCard coupon={wonCoupon} onBookWithCoupon={onBookWithCoupon} />
          </div>

          <div className="max-w-xl mx-auto my-6 text-right">
            <SocialShareCard
              score={5}
              totalQuestions={5}
              discountPercentage={wonCoupon.discountPercentage}
              couponCode={wonCoupon.code}
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-6 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => startLevel(0)}
              className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              إعادة اللعبة من جديد
            </button>
            <button
              onClick={onGoToWheel}
              className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-amber-700 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 hover:bg-amber-100 transition-colors cursor-pointer"
            >
              جرّب عجلة الحظ
            </button>
            <button
              onClick={onGoToQuiz}
              className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-blue-700 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 hover:bg-blue-100 transition-colors cursor-pointer"
            >
              تحدي الأسئلة والمسابقة
            </button>
          </div>
        </div>
      ) : (
        /* Active Interactive Canvas Stage */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
          {/* Level Header & Stats */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-0.5 rounded-full">
                  المستوى {currentLevel.id} من 5
                </span>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  {currentLevel.title}
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentLevel.subtitle}
              </p>
            </div>

            <div className="flex items-center gap-4 shrink-0">
              {/* Clean percent progress */}
              <div className="text-right">
                <span className="text-[11px] text-slate-400 font-semibold block">نسبة النظافة:</span>
                <span className={`font-mono text-lg font-black ${
                  cleanPercent >= currentLevel.targetCleanPercent ? 'text-emerald-600' : 'text-blue-600'
                }`}>
                  %{cleanPercent} / %{currentLevel.targetCleanPercent}
                </span>
              </div>

              {/* Timer */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl font-mono text-sm font-bold text-slate-700 dark:text-slate-200">
                <Clock className="w-4 h-4 text-rose-500" />
                <span>{timeLeft} ث</span>
              </div>
            </div>
          </div>

          {/* Interactive Scratch / Steam Canvas Area */}
          <div className="relative w-full h-[320px] sm:h-[400px] rounded-2xl overflow-hidden border-2 border-slate-200 dark:border-slate-700 shadow-inner select-none cursor-crosshair">
            {/* Clean Pristine Image in Background */}
            <img
              src={currentLevel.image}
              alt={currentLevel.title}
              className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
              referrerPolicy="no-referrer"
            />

            {/* Dirty Grime Canvas on Top */}
            <canvas
              ref={canvasRef}
              width={640}
              height={400}
              onMouseDown={e => {
                isMouseDownRef.current = true;
                applySteamClean(e.clientX, e.clientY);
              }}
              onMouseMove={e => {
                if (isMouseDownRef.current) {
                  applySteamClean(e.clientX, e.clientY);
                }
              }}
              onMouseUp={() => {
                isMouseDownRef.current = false;
                checkCleanliness();
              }}
              onMouseLeave={() => {
                isMouseDownRef.current = false;
              }}
              onTouchStart={e => {
                isMouseDownRef.current = true;
                const touch = e.touches[0];
                if (touch) applySteamClean(touch.clientX, touch.clientY);
              }}
              onTouchMove={e => {
                const touch = e.touches[0];
                if (touch) applySteamClean(touch.clientX, touch.clientY);
              }}
              onTouchEnd={() => {
                isMouseDownRef.current = false;
                checkCleanliness();
              }}
              className="absolute inset-0 w-full h-full touch-none"
            />

            {/* Floating Instructional Tip on Top of Canvas */}
            <div className="absolute bottom-3 left-3 right-3 bg-black/60 backdrop-blur-md rounded-xl p-2.5 text-white text-xs text-center pointer-events-none flex items-center justify-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>حرّك الماوس أو إصبعك لشفط الأوساخ بالبخار وكشف النظافة الحقيقية تحتها!</span>
            </div>
          </div>

          {/* Level Facts */}
          <div className="mt-4 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span><strong>معلومة تقنية:</strong> {currentLevel.facts}</span>
          </div>

          {/* Level Won Banner */}
          {levelWon && (
            <div className="mt-4 p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-500/50 text-center animate-fade-in">
              <div className="flex items-center justify-center gap-2 text-emerald-800 dark:text-emerald-300 font-black text-lg mb-1">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <span>ممتاز! تم تنظيف السطح بنسبة %{cleanPercent}</span>
              </div>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 mb-4">
                ربحت {200 + timeLeft * 10} نقطة إضافية لسرعتك ودقتك في الشفط.
              </p>
              <button
                onClick={handleNextLevel}
                className="px-8 py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-700 shadow-md transition-all cursor-pointer flex items-center gap-2 mx-auto"
              >
                <span>الانتقال للمستوى الموالي</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Level Lost Banner */}
          {levelLost && (
            <div className="mt-4 p-5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border-2 border-rose-500/50 text-center animate-fade-in">
              <span className="text-rose-800 dark:text-rose-300 font-bold text-base block mb-1">
                انتهى الوقت قبل الوصول لنسبة 85%!
              </span>
              <p className="text-xs text-rose-700 dark:text-rose-400 mb-4">
                نظفت {cleanPercent}% فقط. لا تيأس، أعد المحاولة ومرر البخار أسرع!
              </p>
              <button
                onClick={() => startLevel(currentLevelIdx)}
                className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-rose-600 hover:bg-rose-700 shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة هذا المستوى</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
