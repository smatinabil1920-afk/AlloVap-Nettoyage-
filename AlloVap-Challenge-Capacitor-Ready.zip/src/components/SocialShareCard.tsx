import React, { useState } from 'react';
import { Share2, Copy, Check, Sparkles } from 'lucide-react';

interface SocialShareCardProps {
  score: number;
  totalQuestions: number;
  discountPercentage: number;
  couponCode?: string;
}

export const SocialShareCard: React.FC<SocialShareCardProps> = ({
  score,
  totalQuestions,
  discountPercentage,
  couponCode
}) => {
  const [copied, setCopied] = useState(false);
  const percentage = Math.round((score / totalQuestions) * 100);

  // App URL for sharing (uses current window location or fallbacks to development URL)
  const shareUrl = typeof window !== 'undefined' ? window.location.origin : 'https://allovap.tn';

  // Authentic, engaging Tunisian Arabic share message designed to attract more users
  const shareMessage = `🎯 كملت تحدي مسابقة AlloVap في تونس وسجلت سكور ${score}/${totalQuestions} (%${percentage})! 🏆 ربحت كوبون تخفيض فوري بقيمة %${discountPercentage} صالح لـ 7 أيام على تنظيف الصالونات والسيارات بالبخار الجاف! ادخل جرب معلوماتك واربح كوبونك توا: ${shareUrl}`;

  const shareTitle = `تحدي مسابقة AlloVap - ربحت تخفيض %${discountPercentage}!`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareMessage,
          url: shareUrl
        });
      } catch {
        // User cancelled or share failed
      }
    } else {
      handleCopy();
    }
  };

  const openShareWindow = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer,width=600,height=500');
  };

  const shareToWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareMessage)}`;
    openShareWindow(url);
  };

  const shareToFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareMessage)}`;
    openShareWindow(url);
  };

  const shareToTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareMessage)}`;
    openShareWindow(url);
  };

  const shareToTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareMessage)}`;
    openShareWindow(url);
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 via-white to-sky-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-sky-950/20 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-7 shadow-sm text-right">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 border-b border-slate-200/80 dark:border-slate-800/80 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
              شارك نتيجتك مع أصحابك وعائلتك!
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            تحدّى أصحابك يجيبوا سكور أعلى منك ويربحوا كوبونات تخفيض مع AlloVap.
          </p>
        </div>

        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
          <Sparkles className="w-3.5 h-3.5" />
          تخفيض %{discountPercentage} مكتسب
        </span>
      </div>

      {/* Share Preview Snippet Box */}
      <div className="bg-white dark:bg-slate-800/80 rounded-2xl p-4 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-5 relative select-all">
        <p className="line-clamp-3 font-medium">
          {shareMessage}
        </p>
        {couponCode && (
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
            <span>رمز الكوبون الخاص بك: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{couponCode}</strong></span>
            <span>صالح لـ 7 أيام</span>
          </div>
        )}
      </div>

      {/* Social Buttons Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
        {/* WhatsApp Button */}
        <button
          onClick={shareToWhatsApp}
          className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-xs sm:text-sm text-white bg-[#25D366] hover:bg-[#20ba5a] shadow-sm transition-all cursor-pointer active:scale-95"
          title="مشاركة عبر واتساب"
        >
          <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
          </svg>
          <span>واتساب</span>
        </button>

        {/* Facebook Button */}
        <button
          onClick={shareToFacebook}
          className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-xs sm:text-sm text-white bg-[#1877F2] hover:bg-[#166fe5] shadow-sm transition-all cursor-pointer active:scale-95"
          title="مشاركة على فيسبوك"
        >
          <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
            <path d="M9 8H6v4h3v12h5V12h3.642L18 8h-4V6.333C14 5.374 14.5 5 15.583 5H18V0h-3.808C10.596 0 9 1.583 9 4.615V8z" />
          </svg>
          <span>فيسبوك</span>
        </button>

        {/* Telegram Button */}
        <button
          onClick={shareToTelegram}
          className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-xs sm:text-sm text-white bg-[#229ED9] hover:bg-[#1f8fc4] shadow-sm transition-all cursor-pointer active:scale-95"
          title="مشاركة على تيليغرام"
        >
          <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
            <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
          </svg>
          <span>تيليغرام</span>
        </button>

        {/* X / Twitter Button */}
        <button
          onClick={shareToTwitter}
          className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-xs sm:text-sm text-white bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 shadow-sm transition-all cursor-pointer active:scale-95"
          title="مشاركة على إكس (تويتر)"
        >
          <svg className="w-3.5 h-3.5 fill-current shrink-0" viewBox="0 0 24 24">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
          <span>إكس (تويتر)</span>
        </button>
      </div>

      {/* Copy Link & Native Share Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-2 pt-3 border-t border-slate-200/60 dark:border-slate-800/60">
        <button
          onClick={handleCopy}
          className="w-full sm:flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold text-xs sm:text-sm text-slate-700 dark:text-slate-200 transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-emerald-600" />
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">تم نسخ رابط ورسالة المشاركة!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-slate-500" />
              <span>نسخ رسالة التحدي لمشاركتها في الـ SMS أو إنستغرام</span>
            </>
          )}
        </button>

        {typeof navigator !== 'undefined' && typeof navigator.share === 'function' && (
          <button
            onClick={handleNativeShare}
            className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-sky-300 hover:bg-blue-100 font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <Share2 className="w-4 h-4" />
            <span>تطبيقات أخرى (إنستغرام، فايبر...)</span>
          </button>
        )}
      </div>
    </div>
  );
};
