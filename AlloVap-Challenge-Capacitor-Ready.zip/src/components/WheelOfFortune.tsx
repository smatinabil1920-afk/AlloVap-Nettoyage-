import React, { useState, useEffect, useRef } from 'react';
import { WheelPrize, Coupon } from '../types';
import { 
  getWheelPrizesConfig, 
  pickFairWheelPrize, 
  createWheelCoupon 
} from '../utils/couponManager';
import { CouponCard } from './CouponCard';
import { SocialShareCard } from './SocialShareCard';
import { haptic } from '../utils/haptics';
import { 
  Sparkles, 
  RotateCw, 
  Trophy, 
  Frown, 
  ArrowLeft, 
  Tag, 
  Clock, 
  ShieldCheck 
} from 'lucide-react';

interface WheelOfFortuneProps {
  onBookWithCoupon: (code: string) => void;
  onGoToGame: () => void;
  onGoToQuiz: () => void;
}

export const WheelOfFortune: React.FC<WheelOfFortuneProps> = ({
  onBookWithCoupon,
  onGoToGame,
  onGoToQuiz
}) => {
  const [prizes, setPrizes] = useState<WheelPrize[]>([]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [selectedPrize, setSelectedPrize] = useState<WheelPrize | null>(null);
  const [wonCoupon, setWonCoupon] = useState<Coupon | null>(null);
  const [spinCount, setSpinCount] = useState(0);
  const [showResultModal, setShowResultModal] = useState(false);
  const wheelRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    setPrizes(getWheelPrizesConfig());
  }, []);

  const totalSegments = prizes.length || 5;
  const segmentAngle = 360 / totalSegments;

  const handleSpin = () => {
    if (isSpinning || prizes.length === 0) return;
    haptic.medium();

    // 1. Fair probabilistic selection
    const { prize, index } = pickFairWheelPrize(prizes);
    setIsSpinning(true);
    setSelectedPrize(null);
    setWonCoupon(null);
    setShowResultModal(false);

    // 2. Calculate target rotation angle so segment `index` stops precisely at top (12 o'clock)
    // Segment 0 center is at -90 deg (12 o'clock)
    // So segment index center is at (-90 + index * segmentAngle) deg.
    // To land at -90 deg, the rotation must offset: (360 - index * segmentAngle) deg.
    const fullSpins = 6 * 360; // 6 complete rotations
    const safeJitter = (Math.random() - 0.5) * 30; // within +/- 15 deg from center of 72 deg segment
    const targetDeg = rotation + fullSpins + ((360 - (index * segmentAngle)) % 360) + safeJitter;

    // Set rotation state
    setRotation(targetDeg);

    // 3. Wait for the realistic decelerating spin animation to finish (4.5s)
    setTimeout(() => {
      setIsSpinning(false);
      setSelectedPrize(prize);
      setSpinCount(prev => prev + 1);

      // 4. If prize is won, generate official 7-day coupon
      if (prize.discountPercentage > 0 || prize.isFreeService) {
        haptic.success();
        const coupon = createWheelCoupon(prize);
        setWonCoupon(coupon);
      } else {
        haptic.light();
      }
      setShowResultModal(true);
    }, 4600);
  };

  // Helper to draw SVG pie slices
  // Segment i spans from angle (-90 - 36 + i * 72) to (-90 + 36 + i * 72) so center is at -90 + i * 72
  const center = 160;
  const radius = 145;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 text-right animate-fade-in">
      {/* Intro Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm mb-8 text-center sm:text-right flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-3 py-1 rounded-full mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            عجلة الحظ التفاعلية من AlloVap
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
            دوّر العجلة واربح تخفيضاً فورياً أو غسيل ستائر مجاني!
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-xl">
            كل دورة حقيقية وعادلة، والكوبونات الرابحة فريدة وصالحة لمدة <strong>7 أيام كاملة</strong> لخدمات تنظيف وتطهير المفروشات والسيارات في تونس.
          </p>
        </div>

        <div className="flex flex-col items-center sm:items-end gap-1 shrink-0 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold">عدد الدورات:</span>
          <span className="font-mono text-2xl font-black text-blue-600 dark:text-sky-400">{spinCount}</span>
        </div>
      </div>

      {/* Main Wheel Stage */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-lg mb-8 flex flex-col items-center justify-center relative overflow-hidden">
        {/* Top Fixed Pointer (Arrow pointing straight DOWN into 12 o'clock) */}
        <div className="relative z-20 flex flex-col items-center -mb-4">
          <div className="w-8 h-10 drop-shadow-md flex items-center justify-center">
            {/* Crisp SVG needle pointer */}
            <svg viewBox="0 0 32 40" className="w-8 h-10 filter drop-shadow">
              <polygon points="16,38 2,4 30,4" fill="#EF4444" stroke="#991B1B" strokeWidth="2" strokeLinejoin="round" />
              <circle cx="16" cy="12" r="4" fill="#FFFFFF" />
            </svg>
          </div>
        </div>

        {/* The Rotating Wheel Container */}
        <div className="relative w-[300px] h-[300px] sm:w-[340px] sm:h-[340px] rounded-full p-2 bg-gradient-to-tr from-slate-200 via-white to-slate-200 dark:from-slate-700 dark:via-slate-800 dark:to-slate-700 shadow-2xl border-4 border-slate-300 dark:border-slate-700">
          <div className="w-full h-full rounded-full overflow-hidden relative shadow-inner">
            <svg
              ref={wheelRef}
              viewBox="0 0 320 320"
              className="w-full h-full transform-gpu"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: isSpinning
                  ? 'transform 4.5s cubic-bezier(0.12, 0.95, 0.32, 1)'
                  : 'none'
              }}
            >
              {prizes.map((p, idx) => {
                // Calculate angles in degrees
                const startAngleDeg = -90 - segmentAngle / 2 + idx * segmentAngle;
                const endAngleDeg = startAngleDeg + segmentAngle;

                const startRad = (startAngleDeg * Math.PI) / 180;
                const endRad = (endAngleDeg * Math.PI) / 180;

                const x1 = center + radius * Math.cos(startRad);
                const y1 = center + radius * Math.sin(startRad);
                const x2 = center + radius * Math.cos(endRad);
                const y2 = center + radius * Math.sin(endRad);

                const pathData = `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2} Z`;

                // Text position along the center of the sector
                const midAngleDeg = -90 + idx * segmentAngle;
                const midRad = (midAngleDeg * Math.PI) / 180;
                const textRadius = radius * 0.65;
                const tx = center + textRadius * Math.cos(midRad);
                const ty = center + textRadius * Math.sin(midRad);

                return (
                  <g key={p.id}>
                    <path
                      d={pathData}
                      fill={p.color}
                      stroke="#FFFFFF"
                      strokeWidth="2.5"
                    />
                    {/* Prize label rotated along sector */}
                    <text
                      x={tx}
                      y={ty}
                      fill={p.textColor}
                      fontSize="11.5"
                      fontWeight="bold"
                      fontFamily="Cairo, sans-serif"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${midAngleDeg + 90}, ${tx}, ${ty})`}
                      className="select-none pointer-events-none drop-shadow"
                    >
                      {p.label}
                    </text>
                  </g>
                );
              })}

              {/* Center Decorative Cap */}
              <circle cx={center} cy={center} r="26" fill="#0F172A" stroke="#FFFFFF" strokeWidth="4" />
              <circle cx={center} cy={center} r="16" fill="#10B981" />
              <circle cx={center} cy={center} r="6" fill="#FFFFFF" />
            </svg>
          </div>
        </div>

        {/* Spin CTA Button */}
        <div className="mt-8 flex flex-col items-center">
          <button
            onClick={handleSpin}
            disabled={isSpinning}
            className={`px-10 py-4 rounded-2xl font-black text-base sm:text-lg shadow-xl transition-all duration-200 flex items-center gap-3 cursor-pointer select-none active:scale-95 ${
              isSpinning
                ? 'bg-slate-300 dark:bg-slate-700 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-emerald-500 via-teal-600 to-blue-600 hover:from-emerald-600 hover:to-blue-700 text-white hover:shadow-emerald-500/25'
            }`}
          >
            <RotateCw className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
            <span>{isSpinning ? 'العجلة تدور... يا فتاح يا رزاق!' : 'دوّر عجلة الحظ الآن'}</span>
          </button>
          <span className="text-xs text-slate-400 mt-2">
            مضمونة 100% بحساب احتمالات عادل وبكوبونات حقيقية
          </span>
        </div>

        {/* Prizes Legend Bar */}
        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 w-full max-w-xl">
          <span className="text-xs font-bold text-slate-400 block text-center mb-3">
            جوائز العجلة المتاحة:
          </span>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {prizes.map(p => (
              <div
                key={p.id}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border"
                style={{ borderColor: p.color, backgroundColor: `${p.color}15` }}
              >
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                <span className="font-bold text-slate-800 dark:text-slate-200">{p.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Result Display Modal / Card */}
      {showResultModal && selectedPrize && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/40 p-6 sm:p-8 shadow-xl mb-8 animate-fade-in text-center">
          {wonCoupon ? (
            <div>
              <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 mb-4 shadow">
                <Trophy className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
                ألف مبروك! ربحت: {selectedPrize.label}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mb-6">
                {selectedPrize.description}. تم إصدار كوبون حصري صالح لـ 7 أيام!
              </p>

              {/* Coupon card */}
              <div className="max-w-xl mx-auto my-6 text-right">
                <CouponCard coupon={wonCoupon} onBookWithCoupon={onBookWithCoupon} />
              </div>

              {/* Social share card */}
              <div className="max-w-xl mx-auto my-6 text-right">
                <SocialShareCard
                  score={1}
                  totalQuestions={1}
                  discountPercentage={wonCoupon.discountPercentage}
                  couponCode={wonCoupon.code}
                />
              </div>
            </div>
          ) : (
            <div>
              <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 mb-4">
                <Frown className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">
                حظ أوفر في المرة القادمة!
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mb-6">
                ما تيأسش! تنجم تعاود تدوّر العجلة، أو تلعب <strong className="text-emerald-600">لعبة التنظيف</strong> أو تجاوب على <strong className="text-blue-600">الأسئلة</strong> وتربح تخفيضاً مؤكداً لدارك أو كرهبتك.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  onClick={handleSpin}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-slate-900 dark:bg-white dark:text-slate-900 hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  دوّر العجلة مرة أخرى
                </button>
                <button
                  onClick={onGoToGame}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                >
                  العب لعبة التنظيف (تخفيض مؤكد)
                </button>
                <button
                  onClick={onGoToQuiz}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-blue-700 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 transition-colors cursor-pointer"
                >
                  تحدي الأسئلة (152 سؤال)
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
