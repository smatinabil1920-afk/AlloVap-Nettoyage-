import React, { useState } from 'react';
import { ALL_QUESTIONS, CATEGORY_METADATA } from '../data/questions';
import { QuestionCategory } from '../types';
import { Search, Sparkles, Lightbulb, Wrench, ShieldCheck, CheckCircle2, Award } from 'lucide-react';

export const QuestionBankView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<QuestionCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filtered = ALL_QUESTIONS.filter(q => {
    if (selectedCategory !== 'ALL' && q.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const qLower = searchQuery.toLowerCase().trim();
      return (
        q.question.toLowerCase().includes(qLower) ||
        q.explanation.toLowerCase().includes(qLower) ||
        q.subTopic.toLowerCase().includes(qLower) ||
        q.hygieneTip.toLowerCase().includes(qLower)
      );
    }
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 text-right">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6 mb-6">
          <div>
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-sky-400 bg-blue-50 dark:bg-blue-950/40 px-3 py-1 rounded-full mb-2">
              <Award className="w-3.5 h-3.5" />
              الموسوعة التعليمية التونسية للنظافة والتطهير بالبخار
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              بنك أسئلة مسابقة AlloVap (152 سؤالاً كاملاً)
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
              تصفح جميع الأسئلة التعليمية مع التفسيرات العلمية الدقيقة والنصائح الصحية وطرق مساعدة AlloVap.
            </p>
          </div>

          <div className="text-left sm:text-right shrink-0">
            <span className="font-mono text-xs text-slate-500">
              عدد الأسئلة المعروضة: <strong className="text-emerald-600 dark:text-emerald-400 text-sm">{filtered.length}</strong> من 152
            </span>
          </div>
        </div>

        {/* Search Bar & Category Filters */}
        <div className="space-y-4 mb-6">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحث بكلمة مفتاحية (مثال: عث الغبار، الصالون، السيارة، الشحوم، الماطلا...)"
              className="w-full px-4 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                selectedCategory === 'ALL'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              جميع الفئات (152)
            </button>
            {(Object.keys(CATEGORY_METADATA) as QuestionCategory[]).map(catKey => {
              const meta = CATEGORY_METADATA[catKey];
              const isSel = selectedCategory === catKey;
              return (
                <button
                  key={catKey}
                  onClick={() => setSelectedCategory(catKey)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    isSel
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  الفئة {catKey}: {meta.name} ({meta.totalQuestions})
                </button>
              );
            })}
          </div>
        </div>

        {/* Questions List */}
        <div className="space-y-4">
          {filtered.map(q => {
            const isExpanded = expandedId === q.id;

            return (
              <div
                key={q.id}
                className={`rounded-2xl border transition-all text-right ${
                  isExpanded
                    ? 'border-blue-500 bg-blue-50/20 dark:bg-slate-800/80 shadow-sm'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                }`}
              >
                <div
                  onClick={() => setExpandedId(isExpanded ? null : q.id)}
                  className="p-4 sm:p-5 cursor-pointer flex items-start justify-between gap-3"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-1.5">
                      <span className="font-mono text-blue-600 dark:text-sky-400">#{q.id}</span>
                      <span>·</span>
                      <span className="text-slate-700 dark:text-slate-300">{q.categoryTitle}</span>
                      <span>·</span>
                      <span className="text-slate-500">{q.subTopic}</span>
                    </div>
                    <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-relaxed">
                      {q.question}
                    </h4>
                  </div>

                  <div className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300 shrink-0 mt-1">
                    {isExpanded ? '−' : '+'}
                  </div>
                </div>

                {isExpanded && (
                  <div className="px-4 pb-5 sm:px-5 sm:pb-6 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs sm:text-sm space-y-4">
                    {/* Options list */}
                    <div className="space-y-1.5">
                      <span className="text-xs font-bold text-slate-400 block mb-1">الخيارات:</span>
                      {q.options.map((opt, optIdx) => {
                        const isCorrect = optIdx === q.correctIndex;
                        return (
                          <div
                            key={optIdx}
                            className={`p-2.5 rounded-xl border text-right flex items-center justify-between gap-2 ${
                              isCorrect
                                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 font-bold'
                                : 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            <span>{opt}</span>
                            {isCorrect && (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                الإجابة الصحيحة
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Scientific Explanation in Tunisian Arabic */}
                    <div className="bg-sky-50/50 dark:bg-sky-950/30 p-3.5 rounded-xl border border-sky-100 dark:border-sky-900/50">
                      <h5 className="font-bold text-blue-700 dark:text-sky-300 mb-1 flex items-center gap-1.5 text-xs">
                        <Lightbulb className="w-3.5 h-3.5" />
                        <span>الشرح والتوضيح العلمي بالدارجة:</span>
                      </h5>
                      <p className="text-slate-800 dark:text-slate-200 leading-relaxed text-xs sm:text-sm">
                        {q.explanation}
                      </p>
                    </div>

                    {/* Hygiene Tip */}
                    <div className="bg-emerald-50/50 dark:bg-emerald-950/30 p-3.5 rounded-xl border border-emerald-100 dark:border-emerald-900/50">
                      <h5 className="font-bold text-emerald-800 dark:text-emerald-300 mb-1 flex items-center gap-1.5 text-xs">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>نصيحة نظافة وصحة لدارك:</span>
                      </h5>
                      <p className="text-slate-800 dark:text-slate-200 leading-relaxed text-xs sm:text-sm font-medium">
                        {q.hygieneTip}
                      </p>
                    </div>

                    {/* Motivation & AlloVap Help */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                        <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400 block mb-1">
                          تحفيز وتشجيع:
                        </span>
                        <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                          "{q.motivation}"
                        </p>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                        <span className="text-[11px] font-bold text-blue-600 dark:text-sky-400 block mb-1 flex items-center gap-1">
                          <Wrench className="w-3 h-3" />
                          <span>كيفاش تعاونك AlloVap:</span>
                        </span>
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          {q.allovapHelp}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
