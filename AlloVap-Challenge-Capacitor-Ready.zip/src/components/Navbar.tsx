import React from 'react';
import { Sparkles, Moon, Sun, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  activeTab: 'quiz' | 'bank' | 'booking' | 'admin';
  setActiveTab: (tab: 'quiz' | 'bank' | 'booking' | 'admin') => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onStartQuiz: () => void;
  hasActiveCoupon: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  darkMode,
  setDarkMode,
  onStartQuiz,
  hasActiveCoupon
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single brand wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('quiz')}
              className="flex items-center gap-2.5 text-right cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-600 via-blue-600 to-emerald-500 flex items-center justify-center text-white shadow-sm">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col text-right">
                <span className="text-xl font-black tracking-tight text-slate-900 dark:text-white leading-none">
                  Allo<span className="text-emerald-600 dark:text-emerald-400">Vap</span>
                </span>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">
                  Challenge · تونس
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean single-line text links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600 dark:text-slate-300">
            <button
              onClick={() => setActiveTab('quiz')}
              className={`hover:text-blue-600 dark:hover:text-sky-400 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'quiz' ? 'text-blue-600 dark:text-sky-400 border-b-2 border-blue-600 dark:border-sky-400' : ''
              }`}
            >
              التحدي والمسابقة
            </button>
            <button
              onClick={() => setActiveTab('bank')}
              className={`hover:text-blue-600 dark:hover:text-sky-400 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'bank' ? 'text-blue-600 dark:text-sky-400 border-b-2 border-blue-600 dark:border-sky-400' : ''
              }`}
            >
              بنك الأسئلة (152 سؤال)
            </button>
            <button
              onClick={() => setActiveTab('booking')}
              className={`hover:text-blue-600 dark:hover:text-sky-400 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${
                activeTab === 'booking' ? 'text-blue-600 dark:text-sky-400 border-b-2 border-blue-600 dark:border-sky-400' : ''
              }`}
            >
              <span>حجز خدمة بالكوبون</span>
              {hasActiveCoupon && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('admin')}
              className={`hover:text-blue-600 dark:hover:text-sky-400 transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1 ${
                activeTab === 'admin' ? 'text-blue-600 dark:text-sky-400 border-b-2 border-blue-600 dark:border-sky-400' : ''
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-slate-400" />
              <span>إدارة وتأكيد الكوبونات</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action button + Theme toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 rounded-lg transition-colors cursor-pointer"
              aria-label="تبديل المظهر"
            >
              {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              onClick={onStartQuiz}
              className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
            >
              ابدأ التحدي (اربح حتى 10%)
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
