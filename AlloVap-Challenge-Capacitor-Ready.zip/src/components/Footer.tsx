import React from 'react';
import { Sparkles, Phone, MapPin, Mail, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: 'quiz' | 'bank' | 'booking' | 'admin') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-100 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-right py-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-sky-600 via-blue-600 to-emerald-500 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-black text-slate-900 dark:text-white">
                Allo<span className="text-emerald-600 dark:text-emerald-400">Vap</span>
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              الشركة التونسية الرائدة في خدمات التنظيف والتطهير بالبخار الجاف والاستخراج الصناعي للصالونات، السيارات، المراتب والزرابي.
            </p>
            <div className="text-xs text-slate-500 dark:text-slate-500">
              تونس الكبرى وكافة الولايات
            </div>
          </div>

          {/* Nav links */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              أقسام المنصة
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('quiz')}
                  className="hover:text-blue-600 dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  المسابقة والتحدي (اربح كوبون)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('bank')}
                  className="hover:text-blue-600 dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  بنك الأسئلة التعليمي (152 سؤال)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('booking')}
                  className="hover:text-blue-600 dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  حجز موعد خدمة بالكوبون
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin')}
                  className="hover:text-blue-600 dark:hover:text-sky-400 transition-colors cursor-pointer flex items-center gap-1"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>بوابة التحقق الإدارية</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              خدمات AlloVap في تونس
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li>تنظيف صالونات القماش والمخمل بالبخار</li>
              <li>عناية وتغذية الصالونات الجلدية الفاخرة</li>
              <li>غسيل وتطهير المراتب من عث الغبار</li>
              <li>تنظيف صالون كراسي وسقف السيارات بالكامل</li>
              <li>تنظيف الستائر في مكانها بدون فك</li>
              <li>عقود نظافة كراسي ومكاتب الشركات</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              الاتصال والمواعيد
            </h4>
            <div className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-mono dir-ltr">+216 71 850 920 / +216 98 450 120</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>contact@allovap.tn</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>المركز العمراني الشمالي، تونس</span>
              </div>
              <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-200 dark:border-slate-800">
                أوقات العمل الميداني: من الإثنين إلى السبت (8:00 - 18:00)
              </p>
            </div>
          </div>
        </div>

        {/* Legal notice & Accuracy reminder */}
        <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-500">
          <p>
            © {new Date().getFullYear()} AlloVap Tunisie. جميع الحقوق محفوظة. الكوبونات صالحة لـ 7 أيام من تاريخ الإصدار وتخضع للمصادقة الميدانية.
          </p>
          <div className="flex items-center gap-3">
            <span>تطهير بالبخار عالي الكفاءة</span>
            <span>·</span>
            <span>شفافية مهنية تامة</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
