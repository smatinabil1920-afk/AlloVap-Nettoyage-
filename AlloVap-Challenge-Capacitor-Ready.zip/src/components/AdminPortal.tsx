import React, { useState, useEffect } from 'react';
import { 
  getStoredCoupons, 
  getStoredBookings, 
  adminValidateCoupon, 
  formatDateArabic, 
  formatTimeRemaining,
  getWheelPrizesConfig,
  saveWheelPrizesConfig,
  DEFAULT_WHEEL_PRIZES
} from '../utils/couponManager';
import { Coupon, BookingSubmission, WheelPrize } from '../types';
import { 
  ShieldCheck, 
  Search, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  User, 
  AlertTriangle,
  RefreshCw,
  RotateCw,
  Save
} from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [bookings, setBookings] = useState<BookingSubmission[]>([]);
  const [searchCode, setSearchCode] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'used' | 'expired'>('all');
  const [adminNotes, setAdminNotes] = useState('مصادقة المشرف الميداني');
  const [actionMessage, setActionMessage] = useState<{ text: string; success: boolean } | null>(null);
  const [wheelPrizes, setWheelPrizes] = useState<WheelPrize[]>([]);
  const [wheelSaveMsg, setWheelSaveMsg] = useState<string | null>(null);

  const reloadData = () => {
    setCoupons(getStoredCoupons());
    setBookings(getStoredBookings());
    setWheelPrizes(getWheelPrizesConfig());
  };

  useEffect(() => {
    reloadData();
  }, []);

  const handleProbChange = (id: string, newProb: number) => {
    setWheelPrizes(prev =>
      prev.map(p => (p.id === id ? { ...p, probability: Math.max(0, Math.min(100, newProb)) } : p))
    );
  };

  const wheelTotalProb = wheelPrizes.reduce((sum, p) => sum + (Number(p.probability) || 0), 0);

  const handleSaveWheelConfig = () => {
    if (wheelTotalProb !== 100) {
      setWheelSaveMsg('خطأ: مجموع النسب يجب أن يساوي 100% تماماً!');
      setTimeout(() => setWheelSaveMsg(null), 4000);
      return;
    }
    saveWheelPrizesConfig(wheelPrizes);
    setWheelSaveMsg('تم حفظ وتحديث نسب عجلة الحظ بنجاح (المجموع 100%)!');
    setTimeout(() => setWheelSaveMsg(null), 4000);
  };

  const handleResetWheelConfig = () => {
    saveWheelPrizesConfig(DEFAULT_WHEEL_PRIZES);
    setWheelPrizes(DEFAULT_WHEEL_PRIZES);
    setWheelSaveMsg('تمت استعادة النسب الأصلية الافتراضية لعجلة الحظ!');
    setTimeout(() => setWheelSaveMsg(null), 4000);
  };

  const handleValidate = (code: string) => {
    const res = adminValidateCoupon(code, adminNotes);
    setActionMessage({ text: res.message, success: res.success });
    reloadData();
    setTimeout(() => setActionMessage(null), 5000);
  };

  const filteredCoupons = coupons.filter(c => {
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    if (searchCode.trim()) {
      return c.code.toLowerCase().includes(searchCode.toLowerCase().trim());
    }
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-right">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                بوابة إدارة وتأكيد كوبونات AlloVap
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              التحقق الفوري من صلاحية الـ 7 أيام، منع التكرار، وتأكيد حجز الخدمات الميدانية في تونس.
            </p>
          </div>

          <button
            onClick={reloadData}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تحديث البيانات</span>
          </button>
        </div>

        {/* Quick Search & Validation Bar */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 mb-8">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-200 block mb-2">
            فحص وتأكيد كوبون حريف:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="relative col-span-1 sm:col-span-1">
              <input
                type="text"
                value={searchCode}
                onChange={e => setSearchCode(e.target.value)}
                placeholder="أدخل رمز الكوبون..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-mono uppercase text-slate-900 dark:text-white text-right"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            </div>

            <div className="col-span-1 sm:col-span-1">
              <input
                type="text"
                value={adminNotes}
                onChange={e => setAdminNotes(e.target.value)}
                placeholder="ملاحظات المشرف..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white text-right"
              />
            </div>

            <button
              onClick={() => {
                if (searchCode.trim()) handleValidate(searchCode.trim());
              }}
              className="px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-blue-600 hover:bg-blue-700 transition-colors cursor-pointer"
            >
              فحص ومصادقة
            </button>
          </div>

          {actionMessage && (
            <div className={`mt-3 p-3 rounded-xl text-xs font-bold ${
              actionMessage.success
                ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                : 'bg-rose-100 dark:bg-rose-950/50 text-rose-800 dark:text-rose-300'
            }`}>
              {actionMessage.text}
            </div>
          )}
        </div>

        {/* Wheel of Fortune Probabilities Configuration Section (Requirement 2) */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <RotateCw className="w-4 h-4 text-amber-500" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  إعدادات وضبط نسب عجلة الحظ (Wheel of Fortune Probabilities)
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                تعديل احتمالات كل جائزة بدقة؛ يجب أن يكون المجموع الإجمالي مساوياً لـ 100% بالضبط.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`font-mono text-xs font-black px-2.5 py-1 rounded-lg ${
                wheelTotalProb === 100
                  ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                  : 'bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300'
              }`}>
                المجموع: {wheelTotalProb}% {wheelTotalProb === 100 ? '✓ (صحيح)' : '⚠ (يجب أن يساوي 100%)'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 mb-4">
            {wheelPrizes.map((p) => (
              <div
                key={p.id}
                className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-right"
              >
                <div className="flex items-center justify-between gap-1 mb-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate">
                    {p.label}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={p.probability}
                    onChange={(e) => handleProbChange(p.id, Number(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 text-center font-mono font-bold text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="font-mono text-xs font-bold text-slate-500">%</span>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <span className="text-xs text-slate-400">
              النسب الافتراضية: 5%=35% · 10%=15% · 15%=2% · ستائر مجانية=3% · بدون جائزة=45%
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetWheelConfig}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                استعادة الافتراضي
              </button>
              <button
                onClick={handleSaveWheelConfig}
                disabled={wheelTotalProb !== 100}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  wheelTotalProb === 100
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow-sm'
                    : 'bg-slate-300 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Save className="w-3.5 h-3.5" />
                <span>حفظ النسب</span>
              </button>
            </div>
          </div>

          {wheelSaveMsg && (
            <div className={`mt-3 p-2.5 rounded-xl text-xs font-bold text-center ${
              wheelSaveMsg.includes('خطأ')
                ? 'bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300'
                : 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
            }`}>
              {wheelSaveMsg}
            </div>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span className="text-xs font-bold text-slate-400 ml-2">الحالة:</span>
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              statusFilter === 'all'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            الكل ({coupons.length})
          </button>
          <button
            onClick={() => setStatusFilter('active')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              statusFilter === 'active'
                ? 'bg-emerald-600 text-white font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            صالحة ونشطة ({coupons.filter(c => c.status === 'active').length})
          </button>
          <button
            onClick={() => setStatusFilter('used')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              statusFilter === 'used'
                ? 'bg-blue-600 text-white font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            مستعملة ({coupons.filter(c => c.status === 'used').length})
          </button>
          <button
            onClick={() => setStatusFilter('expired')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              statusFilter === 'expired'
                ? 'bg-rose-600 text-white font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            منتهية الصلاحية (7 أيام) ({coupons.filter(c => c.status === 'expired').length})
          </button>
        </div>

        {/* Coupons Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5">رمز الكوبون</th>
                <th className="p-3.5">الخصم</th>
                <th className="p-3.5">تاريخ الإصدار</th>
                <th className="p-3.5">تاريخ الانتهاء (7 أيام)</th>
                <th className="p-3.5">الحالة الحالية</th>
                <th className="p-3.5">الإجراء الإداري</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredCoupons.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400">
                    لا توجد كوبونات تطابق هذا البحث.
                  </td>
                </tr>
              ) : (
                filteredCoupons.map(c => {
                  const rem = formatTimeRemaining(c.expiryDate);

                  return (
                    <tr key={c.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                        {c.code}
                      </td>
                      <td className="p-3.5">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          %{c.discountPercentage}
                        </span>
                        <span className="text-slate-400 mr-1 text-[11px]">({c.score}/{c.totalQuestions})</span>
                      </td>
                      <td className="p-3.5 text-slate-600 dark:text-slate-300">
                        {formatDateArabic(c.issueDate)}
                      </td>
                      <td className="p-3.5 text-slate-600 dark:text-slate-300">
                        <div>{formatDateArabic(c.expiryDate)}</div>
                        {c.status === 'active' && !rem.isExpired && (
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">
                            باقي: {rem.days} ي {rem.hours} س
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        {c.status === 'active' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3" />
                            نشط وصالح
                          </span>
                        ) : c.status === 'used' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3" />
                            مستعمل ومؤكد
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded-full">
                            <AlertTriangle className="w-3 h-3" />
                            منتهي (7 أيام)
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        {c.status === 'active' ? (
                          <button
                            onClick={() => handleValidate(c.code)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition-colors cursor-pointer"
                          >
                            مصادقة واعتماد
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">
                            {c.status === 'used' ? 'تم القبول' : 'ملغى بالوقت'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bookings Overview */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-blue-600" />
          <span>طلبات الحجز المباشرة بالكوبونات ({bookings.length})</span>
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
          الحجوزات الحقيقية التي قام بها الحرفاء بعد استكمال التحدي التعليمي وتطبيق التخفيضات المستحقة.
        </p>

        <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5">رقم الحجز</th>
                <th className="p-3.5">الحريف</th>
                <th className="p-3.5">الهاتف</th>
                <th className="p-3.5">المنطقة</th>
                <th className="p-3.5">الخدمة المطلوبة</th>
                <th className="p-3.5">الكوبون المطبق</th>
                <th className="p-3.5">السعر النهائي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {bookings.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-slate-400">
                    لا توجد حجوزات مسجلة حتى الآن.
                  </td>
                </tr>
              ) : (
                bookings.map(b => (
                  <tr key={b.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                      {b.id}
                    </td>
                    <td className="p-3.5 font-bold text-slate-800 dark:text-slate-200">
                      {b.customerName}
                    </td>
                    <td className="p-3.5 font-mono text-slate-600 dark:text-slate-300">
                      {b.phone}
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">
                      {b.city}
                    </td>
                    <td className="p-3.5 text-slate-700 dark:text-slate-300">
                      {b.serviceType}
                    </td>
                    <td className="p-3.5">
                      {b.couponCode ? (
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                          {b.couponCode} (-{b.discountAmount} DT)
                        </span>
                      ) : (
                        <span className="text-slate-400">بدون كوبون</span>
                      )}
                    </td>
                    <td className="p-3.5 font-bold text-slate-900 dark:text-emerald-400">
                      {b.finalPrice} DT
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
