import React, { useState } from 'react';
import { Question, QuestionCategory, Coupon } from '../types';
import { getChallengeQuestions, CATEGORY_METADATA } from '../data/questions';
import { createCoupon } from '../utils/couponManager';
import { CouponCard } from './CouponCard';
import { SocialShareCard } from './SocialShareCard';
import { haptic } from '../utils/haptics';
import { 
  CheckCircle, 
  XCircle, 
  Lightbulb, 
  Sparkles, 
  Wrench, 
  ArrowLeft, 
  RotateCcw, 
  Trophy, 
  Flame,
  Award
} from 'lucide-react';

interface QuizViewProps {
  onBookWithCoupon: (code: string) => void;
  onExploreBank: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({ onBookWithCoupon, onExploreBank }) => {
  const [quizStarted, setQuizStarted] = useState(false);
  const [selectedLength, setSelectedLength] = useState<number>(10);
  const [selectedCategory, setSelectedCategory] = useState<QuestionCategory | 'ALL'>('ALL');
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [issuedCoupon, setIssuedCoupon] = useState<Coupon | null>(null);

  const startQuiz = () => {
    const filter = selectedCategory === 'ALL' ? undefined : selectedCategory;
    const list = getChallengeQuestions(selectedLength, filter);
    setQuestions(list);
    setCurrentIndex(0);
    setSelectedOption(null);
    setHasAnswered(false);
    setScore(0);
    setQuizFinished(false);
    setIssuedCoupon(null);
    setQuizStarted(true);
  };

  const currentQ = questions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (hasAnswered) return;
    setSelectedOption(idx);
    setHasAnswered(true);

    if (idx === currentQ.correctIndex) {
      haptic.success();
      setScore(prev => prev + 1);
    } else {
      haptic.medium();
    }
  };

  const handleNext = () => {
    haptic.light();
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setHasAnswered(false);
    } else {
      // Quiz finished - generate coupon!
      haptic.success();
      const finalScore = selectedOption === currentQ.correctIndex ? score : score;
      const coupon = createCoupon(finalScore, questions.length);
      setIssuedCoupon(coupon);
      setQuizFinished(true);
    }
  };

  // If quiz is finished, show victory and coupon card
  if (quizFinished && issuedCoupon) {
    const percentage = Math.round((score / questions.length) * 100);

    return (
      <div className="max-w-3xl mx-auto px-4 py-10 text-right animate-fade-in">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-lg text-center">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 via-emerald-500 to-sky-500 flex items-center justify-center text-white shadow-lg mb-6">
            <Trophy className="w-10 h-10 text-white" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
            يعطيك الصحة! كملت التحدي بنجاح
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-xl mx-auto mb-6">
            وعيك وثقافتك في النظافة الصحية ربحتك تخفيضاً فورياً ومباشراً على خدمات AlloVap في تونس.
          </p>

          {/* Score breakdown metrics */}
          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto mb-8">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">النتيجة</span>
              <span className="font-mono text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                {score} / {questions.length}
              </span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">نسبة النجاح</span>
              <span className="font-mono text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400">
                %{percentage}
              </span>
            </div>
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
              <span className="text-xs text-emerald-700 dark:text-emerald-300 block mb-1">التخفيض المكتسب</span>
              <span className="font-mono text-xl sm:text-2xl font-black text-emerald-700 dark:text-emerald-300">
                %{issuedCoupon.discountPercentage}
              </span>
            </div>
          </div>

          {/* The 7-Day Coupon Component */}
          <div className="my-8 text-right">
            <CouponCard coupon={issuedCoupon} onBookWithCoupon={onBookWithCoupon} />
          </div>

          {/* Social Share Section to spread the challenge and attract more participants */}
          <div className="my-6 text-right">
            <SocialShareCard
              score={score}
              totalQuestions={questions.length}
              discountPercentage={issuedCoupon.discountPercentage}
              couponCode={issuedCoupon.code}
            />
          </div>

          {/* Restart or explore options */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-6 pt-6 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={startQuiz}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة التحدي لتحسين النتيجة</span>
            </button>
            <button
              onClick={onExploreBank}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-blue-600 dark:text-sky-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer"
            >
              <span>تصفح كامل بنك الأسئلة (152 سؤال)</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If in active quiz mode
  if (quizStarted && currentQ) {
    const isAnswered = hasAnswered;
    const isCorrect = selectedOption === currentQ.correctIndex;
    const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

    return (
      <div className="max-w-3xl mx-auto px-4 py-8 text-right animate-fade-in">
        {/* Progress & Category Top Bar */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 mb-6 shadow-sm">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300 mb-2">
            <span className="font-mono text-emerald-600 dark:text-emerald-400">
              سؤال {currentIndex + 1} من {questions.length}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 dark:text-slate-400">{currentQ.subTopic}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
              <span className="font-bold text-blue-600 dark:text-sky-400">{currentQ.categoryTitle}</span>
            </div>
          </div>
          <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-emerald-500 to-blue-600 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm mb-6">
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-relaxed mb-6">
            {currentQ.question}
          </h3>

          {/* 4 Options */}
          <div className="space-y-3">
            {currentQ.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isTheCorrectOne = idx === currentQ.correctIndex;

              let btnStyle = 'border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200';

              if (isAnswered) {
                if (isTheCorrectOne) {
                  btnStyle = 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-bold';
                } else if (isSelected && !isCorrect) {
                  btnStyle = 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200';
                } else {
                  btnStyle = 'opacity-40 border-slate-200 dark:border-slate-800 text-slate-500';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-2xl border-2 text-right transition-all flex items-center justify-between gap-3 text-sm sm:text-base leading-relaxed cursor-pointer ${btnStyle}`}
                >
                  <span className="flex-1">{option}</span>
                  <div className="w-7 h-7 rounded-xl border flex items-center justify-center shrink-0 font-mono text-xs font-bold">
                    {isAnswered && isTheCorrectOne ? (
                      <CheckCircle className="w-5 h-5 text-emerald-600" />
                    ) : isAnswered && isSelected && !isCorrect ? (
                      <XCircle className="w-5 h-5 text-rose-600" />
                    ) : (
                      <span>{['أ', 'ب', 'ج', 'د'][idx]}</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* EDUCATIONAL FEEDBACK CARD (Rule 3) */}
        {isAnswered && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/40 dark:border-emerald-500/30 p-6 sm:p-8 shadow-md mb-6 animate-fade-in space-y-5">
            {/* Answer banner */}
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                {isCorrect ? (
                  <span className="inline-flex items-center gap-1.5 text-sm font-black text-emerald-600 dark:text-emerald-400">
                    <CheckCircle className="w-5 h-5" />
                    إجابة صحيحة وممتازة!
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-sm font-black text-amber-600 dark:text-amber-400">
                    <Lightbulb className="w-5 h-5" />
                    إجابة قريبة، اكتشف الشرح الصحيح:
                  </span>
                )}
              </div>
              <span className="text-xs text-slate-400 font-mono">
                ملاحظات تعليمية
              </span>
            </div>

            {/* A. Explanation in Tunisian Arabic */}
            <div className="text-right">
              <h4 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-sky-400 mb-1 flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-blue-500" />
                <span>الشرح والتوضيح العلمي بالدارجة التونسية:</span>
              </h4>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {currentQ.explanation}
              </p>
            </div>

            {/* B. Useful Hygiene Tip */}
            <div className="text-right bg-emerald-50/60 dark:bg-emerald-950/20 rounded-2xl p-4 border border-emerald-100 dark:border-emerald-900/40">
              <h4 className="text-xs font-bold text-emerald-800 dark:text-emerald-300 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>نصيحة نظافة وصحة مفيدة لدارك:</span>
              </h4>
              <p className="text-sm text-emerald-950 dark:text-emerald-200 leading-relaxed font-medium">
                {currentQ.hygieneTip}
              </p>
            </div>

            {/* C. Motivational Message */}
            <div className="text-right">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 mb-1 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-500" />
                <span>كلمة تشجيعية:</span>
              </h4>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic">
                "{currentQ.motivation}"
              </p>
            </div>

            {/* D. How AlloVap can help */}
            {currentQ.allovapHelp && (
              <div className="text-right bg-sky-50/60 dark:bg-sky-950/20 rounded-2xl p-4 border border-sky-100 dark:border-sky-900/40">
                <h4 className="text-xs font-bold text-sky-800 dark:text-sky-300 mb-1 flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-sky-600" />
                  <span>كيفاش AlloVap تنجم تعاونك:</span>
                </h4>
                <p className="text-sm text-sky-950 dark:text-sky-200 leading-relaxed">
                  {currentQ.allovapHelp}
                </p>
              </div>
            )}

            {/* Next question trigger */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={handleNext}
                className="px-6 py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-md transition-all cursor-pointer flex items-center gap-2"
              >
                <span>{currentIndex + 1 < questions.length ? 'السؤال الموالي' : 'مشاهدة النتيجة واستلام الكوبون'}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Quiz Setup / Start Screen
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 text-right">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1 rounded-full mb-3">
            <Award className="w-4 h-4" />
            تحدي المعرفة والنظافة الصحية
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-3">
            اختبر معلوماتك واربح كوبون تخفيض صالح لـ 7 أيام
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed mb-8">
            أجب عن الأسئلة التعليمية في النظافة والتنظيف بالبخار. كل إجابة صحيحة ترفع نسبة تخفيضك من 1% إلى 10% لكوبون فوري وصالح لمدة أسبوع كامل لحجز خدمات AlloVap!
          </p>
        </div>

        {/* Step 1: Select Quiz Length */}
        <div className="mb-8">
          <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">
            1. اختر طول التحدي:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => setSelectedLength(10)}
              className={`p-4 rounded-2xl border-2 text-right transition-all cursor-pointer ${
                selectedLength === 10
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-900 dark:text-white">تحدي الـ 10 أسئلة (الموصى به)</span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">~ 3 دقائق</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                أسئلة متوازنة تغطي الفئات الأربعة بنسق سريع وممتع لربح الكوبون مباشرة.
              </p>
            </button>

            <button
              onClick={() => setSelectedLength(20)}
              className={`p-4 rounded-2xl border-2 text-right transition-all cursor-pointer ${
                selectedLength === 20
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-900 dark:text-white">تحدي الـ 20 سؤالاً المتقدم</span>
                <span className="text-xs font-bold text-blue-600 dark:text-sky-400">~ 6 دقائق</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                تحدٍ أعمق لمحبي التميز واختبار شامل لكافة مجالات الصحة والمفروشات.
              </p>
            </button>
          </div>
        </div>

        {/* Step 2: Select Category Filter */}
        <div className="mb-8">
          <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">
            2. اختر مجال الأسئلة:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`p-3.5 rounded-2xl border-2 text-right transition-all cursor-pointer ${
                selectedCategory === 'ALL'
                  ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/30 font-bold'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <span className="text-sm text-slate-900 dark:text-white block">
                جميع المجالات بالتساوي (مختلط)
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                بنك متكامل يحتوي 152 سؤالاً
              </span>
            </button>

            {(Object.keys(CATEGORY_METADATA) as QuestionCategory[]).map(catKey => {
              const meta = CATEGORY_METADATA[catKey];
              const isSel = selectedCategory === catKey;

              return (
                <button
                  key={catKey}
                  onClick={() => setSelectedCategory(catKey)}
                  className={`p-3.5 rounded-2xl border-2 text-right transition-all cursor-pointer ${
                    isSel
                      ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/30 font-bold'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <span className="text-sm text-slate-900 dark:text-white block">
                    الفئة {catKey}: {meta.name}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    {meta.totalQuestions} سؤال متاح
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Start Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-200 dark:border-slate-800">
          <div className="text-xs text-slate-500 dark:text-slate-400 text-right">
            <span>كل كوبون صالح لمدة <strong>7 أيام كاملة</strong> من تاريخ إصداره، ومخصص للاستعمال الفردي لمرة واحدة.</span>
          </div>

          <button
            onClick={startQuiz}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 via-sky-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-md transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2"
          >
            <span>انطلق في التحدي الآن</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
