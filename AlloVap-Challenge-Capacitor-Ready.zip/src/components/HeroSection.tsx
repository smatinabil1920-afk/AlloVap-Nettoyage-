import React from 'react';
import { Sparkles, ShieldCheck, Award, ArrowLeft, CheckCircle2, ChevronDown } from 'lucide-react';
import { CATEGORY_METADATA } from '../data/questions';
import { QuestionCategory } from '../types';

interface HeroSectionProps {
  onStartQuiz: () => void;
  onExploreBank: () => void;
  onGoToBooking: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartQuiz,
  onExploreBank,
  onGoToBooking
}) => {
  return (
    <div className="text-right">
      {/* Marquee Banner / Top Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-sky-50 via-white to-slate-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 border-b border-slate-200 dark:border-slate-800 py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Right text column (Arabic reading order) */}
            <div className="lg:col-span-7 flex flex-col justify-center">
              {/* Clean unboxed metadata separator as per frontend-design */}
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 mb-4">
                <span>تونس الكبرى وكافة الولايات</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">152 سؤالاً تفاعلياً</span>
                <span aria-hidden="true">·</span>
                <span>كوبونات صالحة لـ 7 أيام</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 dark:text-white leading-[1.25] tracking-tight mb-4" style={{ textWrap: 'balance' }}>
                تحدي <span className="text-transparent bg-clip-text bg-gradient-to-l from-blue-600 to-emerald-600">AlloVap</span> التعليمي: ثقّف روحك واربح تخفيضاً فورياً
              </h1>

              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed mb-6 max-w-2xl">
                أكبر مسابقة توعوية في تونس حول النظافة الصحية والتنظيف بالبخار الاحترافي. أجب عن الأسئلة، اكتشف نصائح صحية مفيدة، واربح كوبون تخفيض حقيقي من <strong>1% إلى 10%</strong> صالح لمدة <strong>7 أيام كاملة</strong> لحجز خدماتنا في منزلك أو لسيارتك.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3 mb-8">
                <button
                  onClick={onStartQuiz}
                  className="px-6 py-3.5 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-md transition-all cursor-pointer active:scale-95 flex items-center gap-2"
                >
                  <span>ابدأ التحدي (اربح حتى 10%)</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={onExploreBank}
                  className="px-5 py-3.5 rounded-xl font-semibold text-xs sm:text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                >
                  تصفح بنك الأسئلة (152 سؤال)
                </button>
                <button
                  onClick={onGoToBooking}
                  className="px-4 py-3.5 text-xs sm:text-sm font-semibold text-blue-600 dark:text-sky-400 hover:underline cursor-pointer"
                >
                  حجز خدمة بالكوبون
                </button>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-6 border-t border-slate-200/80 dark:border-slate-800/80 text-xs">
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>تجهيزات استخراج ألمانية وإيطالية</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>تنقل على عين المكان (À domicile)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300 col-span-2 sm:col-span-1">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>مصداقية علمية وبدون مبالغات</span>
                </div>
              </div>
            </div>

            {/* Left visual column */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xl group">
                <img
                  src="/src/assets/images/allovap_hero_steam_1793672263962.jpg"
                  alt="تنظيف الصالونات بالبخار الجاف والاستخراج من AlloVap"
                  className="w-full h-[360px] sm:h-[420px] object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent flex flex-col justify-end p-6 text-white text-right">
                  <span className="text-xs font-bold text-emerald-400 mb-1 flex items-center gap-1.5 justify-end">
                    <span>تقنية البخار الجاف والشفط المزدوج</span>
                    <Sparkles className="w-3.5 h-3.5" />
                  </span>
                  <h3 className="text-lg font-bold text-white mb-1">
                    تنظيف الأقمشة الصعبة وتفكيك الشحوم من الجذور
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    فعالية تطهير تخضع لدرجة الحرارة وزمن التلامس ونوع النسيج، بدون بلل مفرط ومع جفاف قياسي.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* RULE 5 ACCURACY & HONESTY CHARTER (ميثاق المصداقية والأمانة العلمية) */}
      <section className="py-12 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-8">
            <span className="text-xs font-bold text-blue-600 dark:text-sky-400 uppercase tracking-wider block mb-1">
              ميثاق الشفافية المهنية
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              قواعد المصداقية والأمانة في AlloVap
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              نحن نؤمن بأن ثقة الحريف تُبنى بالحقائق العلمية الصادقة وليس بالوعود التجارية الزائفة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-right">
              <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/60 flex items-center justify-center text-blue-600 dark:text-sky-400 mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                لا ندعي القضاء على 100% من الجراثيم
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                علمياً، لا توجد وسيلة تنظيف تقضي على جميع الميكروبات بنسبة 100%. التطهير بالبخار يقلل البكتيريا بنسب هائلة وموثوقة بأمان.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-right">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-3">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                تطهير مبني على 4 عوامل علمية
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                فعالية التطهير الحقيقية تتوقف على: درجة حرارة البخار، مدة التلامس مع السطح، نوع القماش ومساميته، والتقنية المتبعة.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-right">
              <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 flex items-center justify-center text-amber-600 dark:text-amber-400 mb-3">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                واقعية وأمانة في إزالة البقع
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                لا نزعم إزالة كل بقعة في الكون؛ البقع الكيميائية أو حروق الجافيل المؤكسدة للألياف نشرح وضعها للحريف بأمانة قبل البدء.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-right">
              <div className="w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950/60 flex items-center justify-center text-teal-600 dark:text-teal-400 mb-3">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                تفوق المعدات والخبرة الصناعية
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                الفرق بين التنظيف المنزلي ومعداتنا هو حرارة الغلاية (160°C) والشفط التوربيني المزدوج ومحاليل إيكولوجية معتمدة عالمياً.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* The 4 Educational Categories Showcase (Rule 2) */}
      <section className="py-12 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">
                المحاور الأربعة للمسابقة
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                محاور تحدي AlloVap (152 سؤالاً)
              </h2>
            </div>
            <button
              onClick={onExploreBank}
              className="text-xs font-bold text-blue-600 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>مشاهدة كافة الأسئلة (38 سؤالاً لكل فئة)</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(Object.keys(CATEGORY_METADATA) as QuestionCategory[]).map(catKey => {
              const meta = CATEGORY_METADATA[catKey];

              return (
                <div
                  key={catKey}
                  className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-right shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold text-slate-400">
                      الفئة {catKey} · {meta.totalQuestions} سؤال
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      {meta.nameFr}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                    {meta.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                    {meta.description}
                  </p>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-sky-400">
                    <button
                      onClick={onStartQuiz}
                      className="hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>اختبر معلوماتك في هذه الفئة</span>
                      <ArrowLeft className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Visual Showcases with generated assets */}
      <section className="py-12 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-8">
            <span className="text-xs font-bold text-blue-600 dark:text-sky-400 uppercase tracking-wider block mb-1">
              خدماتنا الميدانية المعتمدة
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              أين يمكنك استعمال كوبون التخفيض؟
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              الكوبونات صالحة لمدة 7 أيام وتُطبق حصرياً على خدمات التنظيف الحقيقية التي نقدمها في تونس.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 group">
              <img
                src="/src/assets/images/allovap_car_interior_1793672265598.jpg"
                alt="تنظيف وتفصيل صالون السيارة بالبخار في تونس"
                className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="p-6 text-right">
                <span className="text-xs font-bold text-blue-600 dark:text-sky-400 mb-1 block">
                  السيارات والـ Habitacle
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  تنظيف وتفصيل صالون السيارة بالكامل
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                  تطهير المقاعد القماشية أو الجلدية، السقف الداخلي، الأبواب، لوحة القيادة، وفتحات التهوئة للقضاء على روائح الرطوبة والدخان والأملاح.
                </p>
                <button
                  onClick={onGoToBooking}
                  className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer justify-end"
                >
                  <span>حجز خدمة السيارة بالكوبون</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 group">
              <img
                src="/src/assets/images/allovap_mattress_clean_1793672264736.jpg"
                alt="تنظيف وتطهير المراتب والماطلا بالبخار في تونس"
                className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="p-6 text-right">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-1 block">
                  غرف النوم والمفروشات
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  غسيل وتطهير المراتب والماطلا (Matelas)
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                  شفط عميق واستخراج لمخلفات عث الغبار وخلايا الجلد الميتة وتصبغات العرق لبيئة نوم صحية تقلل من الحساسية والكحة الصباحية.
                </p>
                <button
                  onClick={onGoToBooking}
                  className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer justify-end"
                >
                  <span>حجز خدمة الماطلا بالكوبون</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
