import React, { useState, useEffect } from 'react';
import { Coupon } from '../types';
import { formatTimeRemaining, formatDateArabic } from '../utils/couponManager';
import { Clock, CheckCircle2, Copy, AlertTriangle, ShieldCheck, ArrowLeft, Tag, Share2, Check } from 'lucide-react';

interface CouponCardProps {
  coupon: Coupon;
  onBookWithCoupon?: (code: string) => void;
  compact?: boolean;
}

export const CouponCard: React.FC<CouponCardProps> = ({ coupon, onBookWithCoupon, compact = false }) => {
  const [copied, setCopied] = useState(false);
  const [showShareStrip, setShowShareStrip] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(formatTimeRemaining(coupon.expiryDate));

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(formatTimeRemaining(coupon.expiryDate));
    }, 1000);
    return () => clearInterval(timer);
  }, [coupon.expiryDate]);

  const handleCopy = () => {
    navigator.clipboard.writeText(coupon.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const isExpired = coupon.status === 'expired' || timeLeft.isExpired;
  const isUsed = coupon.status === 'used';

  return (
    <div className={`relative overflow-hidden rounded-2xl border transition-all ${
      isUsed
        ? 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 opacity-90'
        : isExpired
        ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
        : 'bg-gradient-to-br from-white via-sky-50/40 to-emerald-50/40 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/20 border-emerald-300 dark:border-emerald-800 shadow-md'
    }`}>
      {/* Decorative dashed ticket cutout notches */}
      <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-slate-700" />
      <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-slate-700" />

      <div className="p-5 sm:p-6 text-right">
        {/* Header line with status */}
        <div className="flex items-center justify-between gap-2 border-b border-dashed border-slate-200 dark:border-slate-700 pb-3 mb-4">
          <div className="flex items-center gap-2">
            {isUsed ? (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 dark:text-slate-400">
                <CheckCircle2 className="w-3.5 h-3.5 text-slate-500" />
                تم استعمال الكوبون والمصادقة
              </span>
            ) : isExpired ? (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400">
                <AlertTriangle className="w-3.5 h-3.5" />
                منتهي الصلاحية (مرت 7 أيام)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
                <Tag className="w-3.5 h-3.5 text-emerald-600" />
                كوبون نشط وحصري (صالح لـ 7 أيام)
              </span>
            )}
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            تحدي AlloVap
          </span>
        </div>

        {/* Discount highlight & Code */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 my-2">
          <div className="text-right">
            <div className="flex items-baseline gap-1 text-slate-900 dark:text-white">
              <span className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-l from-blue-600 to-emerald-600">
                %{coupon.discountPercentage}
              </span>
              <span className="text-lg font-bold text-slate-700 dark:text-slate-300">
                تخفيض مباشر
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              مبني على نتيجتك: {coupon.score} من {coupon.totalQuestions} إجابات صحيحة
            </p>
          </div>

          <div className="flex flex-col items-center sm:items-end gap-2 w-full sm:w-auto">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 border-2 border-dashed border-emerald-500/50 dark:border-emerald-500/40 rounded-xl px-4 py-2.5">
              <span className="font-mono text-lg sm:text-xl font-black tracking-wider text-slate-900 dark:text-emerald-300 select-all">
                {coupon.code}
              </span>
              <button
                onClick={handleCopy}
                disabled={isExpired || isUsed}
                className="p-1.5 text-slate-500 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                title="نسخ الرمز"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            {copied && (
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 animate-fade-in">
                تم نسخ رمز الكوبون بنجاح!
              </span>
            )}
          </div>
        </div>

        {/* Live Countdown & Dates */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
          <div className="flex flex-col gap-1 text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
              <Clock className="w-3.5 h-3.5 text-blue-500" />
              <span>فترة الصلاحية المحددة:</span>
            </div>
            <span className="font-semibold">
              تاريخ الإصدار: {formatDateArabic(coupon.issueDate)}
            </span>
            <span className="font-semibold text-rose-600 dark:text-rose-400">
              ينتهي وجوباً في: {formatDateArabic(coupon.expiryDate)}
            </span>
          </div>

          <div className="flex flex-col justify-center sm:items-end">
            {!isExpired && !isUsed ? (
              <div className="bg-emerald-500/10 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl p-2.5 text-center sm:text-right w-full sm:w-auto">
                <span className="text-[11px] text-emerald-700 dark:text-emerald-300 font-medium block">
                  العد التنازلي لانتهاء الصلاحية (7 أيام):
                </span>
                <span className="font-mono text-xs sm:text-sm font-bold text-emerald-800 dark:text-emerald-200 block mt-0.5">
                  {timeLeft.days} يوم · {timeLeft.hours} س · {timeLeft.minutes} د · {timeLeft.seconds} ث
                </span>
              </div>
            ) : isUsed ? (
              <div className="text-right text-xs text-slate-500 dark:text-slate-400">
                <p>تاريخ الاستعمال: {coupon.usedAt ? formatDateArabic(coupon.usedAt) : 'تم الاستعمال'}</p>
                {coupon.usedBookingId && <p className="font-mono">رقم الحجز: {coupon.usedBookingId}</p>}
                {coupon.validatedBy && <p>المصادق: {coupon.validatedBy}</p>}
              </div>
            ) : (
              <div className="text-right text-xs text-rose-600 dark:text-rose-400 font-semibold">
                تم انتهاء صلاحية الكوبون تلقائياً بعد مرور 7 أيام كاملة. يمكنك إعادة التحدي للحصول على كوبون جديد!
              </div>
            )}
          </div>
        </div>

        {/* Business and educational conditions disclaimer */}
        <div className="mt-4 pt-3 border-t border-dashed border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed flex items-start gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>
            <strong>شروط الاستعمال:</strong> صالح لمرة واحدة فقط لحجز خدمة تنظيف وتطهير حقيقية لدى AlloVap. يتم تفعيله وتأكيده رسمياً من قبل إدارة AlloVap. لا يمكن دمجه مع عروض ترويجية أخرى.
          </span>
        </div>

        {/* Quick Social Share Strip if toggled */}
        {showShareStrip && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 animate-fade-in text-right">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-200 block mb-2">
              شارك نتيجتك وكوبون الـ %{coupon.discountPercentage} مع أصحابك:
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => {
                  const msg = `🎯 كملت تحدي AlloVap وسجلت ${coupon.score}/${coupon.totalQuestions} وربحت كوبون تخفيض %${coupon.discountPercentage} (الرمز: ${coupon.code}) صالح لـ 7 أيام على تنظيف الصالون والكرهبة بالبخار! جرب حظك توا: ${window.location.origin}`;
                  window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-[#25D366] hover:bg-[#20ba5a] transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>واتساب</span>
              </button>
              <button
                onClick={() => {
                  const url = window.location.origin;
                  const quote = `🎯 ربحت تخفيض %${coupon.discountPercentage} في تحدي AlloVap لتنظيف الصالونات والسيارات بالبخار في تونس! جرب حظك: ${url}`;
                  window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(quote)}`, '_blank');
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-[#1877F2] hover:bg-[#166fe5] transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>فيسبوك</span>
              </button>
              <button
                onClick={() => {
                  const msg = `🎯 كملت تحدي AlloVap وسجلت ${coupon.score}/${coupon.totalQuestions} وربحت تخفيض %${coupon.discountPercentage} مع AlloVap! ادخل جرب حظك توا: ${window.location.origin}`;
                  navigator.clipboard.writeText(msg);
                  setShareCopied(true);
                  setTimeout(() => setShareCopied(false), 2500);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 hover:bg-slate-100 transition-all cursor-pointer flex items-center gap-1.5"
              >
                {shareCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>نسخ النص</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-4 pt-3 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => setShowShareStrip(!showShareStrip)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{showShareStrip ? 'إخفاء أزرار المشاركة' : 'مشاركة نتيجتي عبر التواصل الاجتماعي'}</span>
          </button>

          {!compact && !isExpired && !isUsed && onBookWithCoupon && (
            <button
              onClick={() => onBookWithCoupon(coupon.code)}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-sm transition-all cursor-pointer mr-auto"
            >
              <span>احجز خدمتك الآن بتخفيض %{coupon.discountPercentage}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
