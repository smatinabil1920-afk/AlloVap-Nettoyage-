import React, { useState, useEffect, useRef } from 'react';
import { 
  Smartphone, 
  Download, 
  CheckCircle, 
  MoreVertical, 
  Sparkles, 
  X, 
  ShieldCheck, 
  QrCode, 
  Copy, 
  Check, 
  MessageSquare, 
  ExternalLink 
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { haptic } from '../utils/haptics';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isStandalone, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'instructions' | 'qr'>('instructions');
  const [copied, setCopied] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  
  // Public install URL for the app
  const appUrl = typeof window !== 'undefined' 
    ? (window.location.origin.includes('localhost') || window.location.origin.includes('run.app')
        ? window.location.origin
        : 'https://ais-pre-b74b3viyz3iu2g4pf3vjzj-217367114759.europe-west3.run.app')
    : 'https://ais-pre-b74b3viyz3iu2g4pf3vjzj-217367114759.europe-west3.run.app';

  // Generate QR Code data URL when modal opens
  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(appUrl, {
        width: 260,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then(url => setQrDataUrl(url))
        .catch(err => console.error('Failed to generate QR code', err));
    }
  }, [isOpen, appUrl]);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    haptic.medium();
    if (isInstallable) {
      const outcome = await install();
      if (outcome) {
        haptic.success();
      }
    }
  };

  const handleCopyLink = () => {
    haptic.light();
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareWhatsApp = () => {
    haptic.light();
    const text = encodeURIComponent(
      `حمّل تطبيق AlloVap الرسمي للتنظيف بالبخار والتحديات التونسية من الرابط:\n${appUrl}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl text-white max-h-[92vh] overflow-y-auto"
        dir="rtl"
      >
        {/* Close Button */}
        <button
          onClick={() => {
            haptic.light();
            onClose();
          }}
          className="absolute top-4 left-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Icon */}
        <div className="text-center pt-2 pb-3">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-cyan-500 p-1 shadow-lg shadow-emerald-500/25 mb-2 ring-4 ring-emerald-500/20">
            <img src="/pwa-192x192.png" alt="AlloVap Icon" className="w-full h-full object-contain rounded-xl" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-2">
            <Smartphone className="w-3.5 h-3.5" />
            <span>تطبيق أندرويد الرسمي (Android WebAPK)</span>
          </div>

          <h2 className="text-2xl font-black text-white">
            تحميل وتثبيت تطبيق <span className="text-emerald-400">AlloVap</span>
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1">
            يعمل كتطبيق أصلي شاشة كاملة دون الحاجة لتحميل ملفات APK غير آمنة أو متجر خارجي
          </p>
        </div>

        {/* Tab selection */}
        <div className="flex bg-slate-800/80 p-1 rounded-xl mb-5 border border-slate-700/60">
          <button
            onClick={() => {
              haptic.light();
              setActiveTab('instructions');
            }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'instructions'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>التثبيت على الهاتف</span>
          </button>
          <button
            onClick={() => {
              haptic.light();
              setActiveTab('qr');
            }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'qr'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>مسح كود QR بالكاميرا</span>
          </button>
        </div>

        {/* Tab 1: Instructions & Direct Install */}
        {activeTab === 'instructions' && (
          <div>
            {isStandalone || isInstalled ? (
              <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 text-center mb-5">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
                <h3 className="font-bold text-emerald-200">التطبيق مُثبت بالفعل على هاتفك!</h3>
                <p className="text-xs text-emerald-300/80 mt-1">
                  أنت تستخدم تطبيق AlloVap بأعلى أداء ووضع الشاشة الكاملة.
                </p>
              </div>
            ) : (
              <>
                {/* 1-Click Native Install if available */}
                {isInstallable && (
                  <div className="mb-5">
                    <button
                      onClick={handleInstallClick}
                      className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-black text-base shadow-lg shadow-emerald-500/30 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download className="w-5 h-5" />
                      <span>اضغط هنا لتثبيت التطبيق فوراً</span>
                    </button>
                    <p className="text-center text-[11px] text-slate-400 mt-1.5">
                      ستظهر نافذة نظام أندرويد لتأكيد إضافة الأيقونة لشاشتك
                    </p>
                  </div>
                )}

                {/* Android Chrome Step-by-Step Guide */}
                <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-4 mb-4">
                  <h4 className="text-xs font-bold text-cyan-300 flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    خطوات التثبيت من متصفح الهاتف (Chrome / Samsung):
                  </h4>

                  <div className="space-y-2.5 text-xs text-slate-200">
                    <div className="flex items-start gap-3 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                      <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">
                        1
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-white">اضغط على زر القائمة (⋮) بالمتصفح</p>
                        <p className="text-slate-400 text-[11px]">في أعلى أو أسفل شاشة المتصفح</p>
                      </div>
                      <MoreVertical className="w-4 h-4 text-slate-400 shrink-0" />
                    </div>

                    <div className="flex items-start gap-3 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                      <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">
                        2
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-white">اختر "تثبيت التطبيق" أو "إضافة للشاشة الرئيسية"</p>
                        <p className="text-slate-400 text-[11px]">Install app / Add to Home screen</p>
                      </div>
                      <Download className="w-4 h-4 text-emerald-400 shrink-0" />
                    </div>

                    <div className="flex items-start gap-3 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                      <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">
                        3
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-white">انقر على "تثبيت"</p>
                        <p className="text-slate-400 text-[11px]">يضاف التطبيق لأيقونات هاتفك بجانب واتساب وفيسبوك</p>
                      </div>
                      <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Tab 2: QR Code Scan */}
        {activeTab === 'qr' && (
          <div className="text-center py-2 animate-fadeIn">
            <p className="text-xs text-slate-300 mb-3">
              افتح كاميرا هاتف أندرويد ووجّهها إلى هذا الرمز لفتح وتثبيت التطبيق مباشرة:
            </p>

            <div className="inline-block p-3.5 bg-white rounded-2xl shadow-xl shadow-black/40 border-4 border-emerald-500/40 mb-3">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="AlloVap QR Code" className="w-48 h-48 mx-auto object-contain" />
              ) : (
                <div className="w-48 h-48 flex items-center justify-center text-slate-600 text-xs">
                  جاري تجهيز الكود...
                </div>
              )}
            </div>

            <div className="text-[11px] text-emerald-400 font-bold mb-4 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>يتعرف عليه الهاتف فوراً ويفتح صفحة التثبيت</span>
            </div>
          </div>
        )}

        {/* Share & Copy Link Section */}
        <div className="pt-3 border-t border-slate-800/80 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-400 font-mono text-left focus:outline-none select-all"
              dir="ltr"
            />
            <button
              onClick={handleCopyLink}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="flex-1 py-2 px-3 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-slate-950 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-98"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              <span>إرسال الرابط لهاتفي عبر واتساب</span>
            </button>
          </div>
        </div>

        {/* Trust Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>تطبيق رسمي مشفر وآمن 100%</span>
          </div>
          <button
            onClick={() => {
              haptic.light();
              onClose();
            }}
            className="text-slate-300 hover:text-white underline underline-offset-4 cursor-pointer"
          >
            إغلاق ومتابعة اللعب
          </button>
        </div>
      </div>
    </div>
  );
};
