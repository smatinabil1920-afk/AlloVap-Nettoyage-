export type QuestionCategory = 'A' | 'B' | 'C' | 'D';

export interface Question {
  id: number;
  category: QuestionCategory;
  categoryTitle: string;
  subTopic: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  hygieneTip: string;
  motivation: string;
  allovapHelp: string;
}

export type CouponStatus = 'active' | 'used' | 'expired';

export interface Coupon {
  id: string;
  code: string;
  discountPercentage: number;
  score: number;
  totalQuestions: number;
  issueDate: string; // ISO string
  expiryDate: string; // ISO string (exactly 7 days)
  status: CouponStatus;
  usedAt?: string;
  usedBookingId?: string;
  validatedBy?: string;
  prizeType?: 'quiz' | 'wheel' | 'game';
  freeServiceName?: string;
}

export interface WheelPrize {
  id: string;
  label: string;
  description: string;
  discountPercentage: number;
  isFreeService?: boolean;
  color: string;
  textColor: string;
  probability: number; // in percent (e.g. 35)
}

export interface CleaningLevel {
  id: number;
  title: string;
  subtitle: string;
  image: string;
  targetCleanPercent: number;
  timeLimitSeconds: number;
  facts: string;
}

export interface BookingSubmission {
  id: string;
  customerName: string;
  phone: string;
  city: string;
  address: string;
  serviceType: string;
  preferredDate: string;
  couponCode?: string;
  originalPrice: number;
  discountAmount: number;
  finalPrice: number;
  notes?: string;
  createdAt: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
}
