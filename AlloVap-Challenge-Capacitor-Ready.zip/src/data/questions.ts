import { Question, QuestionCategory } from '../types';
import { questionsCategoryA } from './questionsA';
import { questionsCategoryB } from './questionsB';
import { questionsCategoryC } from './questionsC';
import { questionsCategoryD } from './questionsD';

export const ALL_QUESTIONS: Question[] = [
  ...questionsCategoryA,
  ...questionsCategoryB,
  ...questionsCategoryC,
  ...questionsCategoryD
];

export const CATEGORY_METADATA: Record<QuestionCategory, {
  name: string;
  nameFr: string;
  description: string;
  iconName: string;
  badgeColor: string;
  totalQuestions: number;
}> = {
  A: {
    name: 'مزايا التنظيف بالبخار',
    nameFr: 'Avantages du Nettoyage Vapeur',
    description: 'تفكيك الشحوم، الحد من الميكروبات بدون مبالغة، تنظيف المفروشات الدقيقة، والطرق السليمة للبخار الجاف.',
    iconName: 'Sparkles',
    badgeColor: 'text-sky-600 bg-sky-50 dark:bg-sky-950/40 dark:text-sky-400',
    totalQuestions: questionsCategoryA.length
  },
  B: {
    name: 'الوعي بالصحة والنظافة',
    nameFr: 'Santé, Hygiène & Prévention',
    description: 'عث الغبار في الماطلا والصالون، عادات النظافة اليومية، جودة هواء السيارة، وصحة البيوت ومقرات العمل.',
    iconName: 'ShieldCheck',
    badgeColor: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400',
    totalQuestions: questionsCategoryB.length
  },
  C: {
    name: 'التنظيف الاحترافي مقابل التنظيف العادي',
    nameFr: 'Nettoyage Pro vs Nettoyage Ordinaire',
    description: 'قوة الحقن والاستخراج الصناعي، أهمية الخبرة، المعاملة الصحيحة لكل نسيج، وحماية الأثاث من التلف.',
    iconName: 'Wrench',
    badgeColor: 'text-blue-600 bg-blue-50 dark:bg-blue-950/40 dark:text-blue-400',
    totalQuestions: questionsCategoryC.length
  },
  D: {
    name: 'التحفيز والتوعية',
    nameFr: 'Motivation & Sensibilisation',
    description: 'لماذا نهتم بالصالونات والسيارات والستائر والماطلا بانتظام؟ ولماذا اختيار متخصص مثل AlloVap؟',
    iconName: 'Award',
    badgeColor: 'text-teal-600 bg-teal-50 dark:bg-teal-950/40 dark:text-teal-400',
    totalQuestions: questionsCategoryD.length
  }
};

/**
 * Shuffles questions with Fisher-Yates and picks a balanced challenge set
 */
export function getChallengeQuestions(count: number = 10, categoryFilter?: QuestionCategory): Question[] {
  let pool = categoryFilter
    ? ALL_QUESTIONS.filter(q => q.category === categoryFilter)
    : [...ALL_QUESTIONS];

  // If selecting all categories without filter, ensure balance across all 4 categories
  if (!categoryFilter && count >= 4) {
    const perCat = Math.floor(count / 4);
    const remainder = count % 4;

    const a = shuffle([...questionsCategoryA]).slice(0, perCat + (remainder > 0 ? 1 : 0));
    const b = shuffle([...questionsCategoryB]).slice(0, perCat + (remainder > 1 ? 1 : 0));
    const c = shuffle([...questionsCategoryC]).slice(0, perCat + (remainder > 2 ? 1 : 0));
    const d = shuffle([...questionsCategoryD]).slice(0, perCat);

    return shuffle([...a, ...b, ...c, ...d]);
  }

  return shuffle(pool).slice(0, count);
}

function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
